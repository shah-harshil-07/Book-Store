<?php echo $__env->make("layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1 style="margin-top: 30px;">Your Orders</h1>
<div style="margin-top: 30px;">
    <b style="margin-left: 100px; font-size: 18;">Book</b>
    <b style="margin-left: 160px; font-size: 18;">Details</b>
</div>
<hr>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $theme; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <img src="<?php echo e($detail->Image); ?>">
        <div style="margin-left: 300px; margin-top: -190px;">
            <p>
                <b><?php echo e($detail->Name); ?></b>
            </p>
            
            <p>
                Qty: <b><?php echo e($detail->Quantity); ?></b>
            </p>
            
            <p>
                Total Amount Paid: <b>₹<?php echo e($detail->Total_Cost); ?></b>
            </p>
            
            <p>
                Delivery Status: <b><?php echo e($detail->Delivery_Status); ?></b>
            </p>
            <p style="margin-top: 20px;">
                <a href="/details/<?php echo e($detail->Theme); ?>/<?php echo e($detail->Product_id); ?>">
                    <button class="btn btn-outline-info">Product details</button>
                </a>
                <a href="/e_bill/<?php echo e($detail->Theme); ?>/<?php echo e($detail->Product_id); ?>/<?php echo e($detail->Quantity); ?>" 
                style="margin-left: 20px;">View e-bill</a>
            </p>
        </div>
        <hr style="margin-top: 30px;">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\Book_Store\resources\views/Cart_&_Orders/orders_list.blade.php ENDPATH**/ ?>