<!DOCTYPE html>
<html>
    <head>
        <title>Account Settings</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <style>
            body
            {
                background-image: url('https://i.pinimg.com/originals/9a/39/a3/9a39a344c61cb7a99517549b5acc8df7.jpg');
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: 100% 100%; 	
            }
            ::placeholder
            {
                color: #ff0000 !important;
                font-weight: bold;
            }
        </style>
    </head>
    <body class="container">

        <div style="border: 2px solid black; margin-top: 60px; height: 600px; width: 500px;
            margin-left: 300px;">

            <div style="margin-left: 30px; margin-top: -30px; margin-bottom: 100px; 
                margin-right: 30px;" class="was-validated">

                <h1 style="margin-top: 40px; text-align: center">ACCOUNT SETTINGS</h1>

                <p style="text-align: center; color: red">Following are your account details</p>

                <form class="form-group col-md-12" method="POST" action="acc_update">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo csrf_field(); ?>
                        <p>
                            <input type="text" name="fname" placeholder="FIRST NAME" 
                            class="form-control" required="Please fill out this field" 
                            style="background: rgba(0,0,0,0);" value='<?php echo e($item->First_Name); ?>'>
                        </p>

                        <p>
                            <input type="text" name="lname" placeholder="LAST NAME" 
                            class="form-control" required="Please fill out this field"
                            style="background: rgba(0,0,0,0);" value='<?php echo e($item->Last_Name); ?>'>
                        </p>

                        <p>
                            <input type="text" name="email" placeholder="EMAIL ADDRESS" 
                            class="form-control" required="Please fill out this field"
                            style="background: rgba(0,0,0,0);" value='<?php echo e($item->Email); ?>'>
                        </p>

                        <p>
                            <input type="text" name="apt" placeholder="APT. NO./NAME WITH SOCIETY NAME" 
                            class="form-control" required="Please fill out this field" 
                            style="background: rgba(0,0,0,0);" value='<?php echo e($item->Apartment); ?>'>
                        </p>

                        <p>
                            <input type="text" name="street" placeholder="STREET NAME" 
                            class="form-control" required="Please fill out this field"
                            style="background: rgba(0,0,0,0);" value='<?php echo e($item->Street); ?>'>
                        </p>

                        <p>
                            <input type="text" name="city" placeholder="CITY NAME" 
                            class="form-control" required="Please fill out this field"
                            style="background: rgba(0,0,0,0);" value='<?php echo e($item->City); ?>'>
                        </p>

                        <p>
                            <input type="text" name="state" placeholder="STATE NAME" 
                            class="form-control" required="Please fill out this field"
                            style="background: rgba(0,0,0,0);" value='<?php echo e($item->State); ?>'>
                        </p>
                        
                        <p>
                            <input type="submit" name="submit" class="btn btn-secondary 
                            col-md-12" value="Update Account">
                        </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </form>
                <p style="text-align: center;">
                    <a href="alt_pass">Change the Password</a>
                </p>
            </div>
        </div>
    </body>
</html><?php /**PATH D:\xampp\htdocs\Book_Store\resources\views/Accounts/acc_set.blade.php ENDPATH**/ ?>