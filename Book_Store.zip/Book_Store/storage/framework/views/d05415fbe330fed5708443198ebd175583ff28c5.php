<html>
<head>
	<title>Product Page</title>

	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

	<style>
		img
		{
			width: 160px;
			height: 190px;
			margin-left: 50px;
		}
		.mag
		{
			width: 1500px;
			height: 500px;
		}
		.theme
		{
			width: 400px;
			height: 70px;
			margin-left: 30px;
			margin-top: 10px;
		}
		body
		{
			background-image: url('https://i.pinimg.com/736x/6e/a7/65/6ea765d576e770c1427717a704708a29.jpg');
			background-repeat: no-repeat;
			background-attachment: fixed;
			background-size: 100% 100%; 	
		}
	</style>
    <body class="container-fluid">
       <?php /**PATH D:\xampp\htdocs\BookStore\resources\views/master.blade.php ENDPATH**/ ?>