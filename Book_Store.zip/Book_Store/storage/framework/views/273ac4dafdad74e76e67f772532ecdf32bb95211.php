<div style="text-align: center;margin-top: 50px;">
		<div style="background-color: black; color: white; opacity: 0.7">
			<p><i>We read to know we're not alone.</i></p>
			<p><i>Reading is a discount ticket to everywhere.</i></p>
			<p><i>If one cannot enjoy reading a book over and over again, there is no use in reading it at all.</i></p>
			<p><i>A book is a garden, an orchard, a storehouse, a party, a company by the way, a counselor, a multitude of counselors.</i></p>
		</div>
	</div>
</body>
</html><?php /**PATH D:\xampp\htdocs\BookStore\resources\views/components/footer.blade.php ENDPATH**/ ?>