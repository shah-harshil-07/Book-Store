<?php echo $__env->make("layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<h2>FROM YOUR LIBRARY</h2>
	<h2>NEW ARRIVALS</h2>
	<marquee direction="left">
		<a href="details/new_arr/1">
			<img src="https://images-na.ssl-images-amazon.com/images/I/81tHdhbrGEL.jpg">
		</a>
		<a href="details/new_arr/2">
			<img src="https://m.media-amazon.com/images/I/51npJeaLSeL._SY346_.jpg">
		</a>
		<a href="details/new_arr/3">
			<img src="https://m.media-amazon.com/images/I/4183W2pkyrL.jpg">
		</a>
		<a href="details/new_arr/4">
			<img src="https://m.media-amazon.com/images/I/51BtlJLvmbL.jpg">
		</a>
		<a href="details/new_arr/5">
			<img src="https://m.media-amazon.com/images/I/41e3duN8iOL.jpg">
		</a>
	</marquee><br><br>

	<h2>READ WONDERFUL MAGAZINES</h2>
	<div id="demo" class="carousel slide" data-ride="carousel">
	 	<ul class="carousel-indicators">
	    	<li data-target="#demo" data-slide-to="0" class="active"></li>
	    	<li data-target="#demo" data-slide-to="1"></li>
	    	<li data-target="#demo" data-slide-to="2"></li>
	  	</ul>
	  	<div class="carousel-inner">
	    	<div class="carousel-item active">
				<a href="details/mag/1">
					<img src="https://media.nbcboston.com/2020/12/Time-Person-of-the-Year-2020.gif?resize=850%2C478&quality=85&strip=all" class="mag">
				</a>
	    </div>
    	<div class="carousel-item">
			<a href="details/mag/2">
				<img src="https://akm-img-a-in.tosshub.com/sites/btmt/images/stories/modi_time_magazine-660x450_051019043545.jpg" class="mag">
			</a>  
    	</div>
    	<div class="carousel-item">
			<a href="details/mag/3">
				<img src="https://images.news18.com/ibnlive/uploads/2021/03/1614921344_time-magazine.png" class="mag">
			</a>   
    	</div>
  		<a class="carousel-control-prev" href="#demo" data-slide="prev">
  			<span class="carousel-control-prev-icon"></span>
  		</a>
  		<a class="carousel-control-next" href="#demo" data-slide="next">
    		<span class="carousel-control-next-icon"></span>
  		</a>
	</div><br><br>

	<h2>PICK A THEME</h2>
	<a href="mystery">
		<button class="btn btn-outline-dark theme">Mystery, Thriller, Crime</button>
	</a>
	<a href="romance">
		<button class="btn btn-outline-danger theme">Romance, Couple, Love</button>
	</a>
	<a href="sci">
		<button class="btn btn-outline-info theme">Science Fiction</button>
	</a>
	<a href="biz">
		<button class="btn btn-outline-success theme">Business, Management, Finance</button>
	</a>
	<a href="mot">
		<button class="btn btn-outline-warning theme">Motivation</button>
	</a>
	<a href="bio">
		<button class="btn btn-outline-secondary theme">Biography</button>
	</a><br><br><br><br>

<?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\BookStore\resources\views/Main_Page.blade.php ENDPATH**/ ?>