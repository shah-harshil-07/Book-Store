<?php echo $__env->make("layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div style="display: none;"><?php echo e($a=1); ?></div>

<div style="margin-top: 30px;">
	<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
		<?php $__currentLoopData = $mystery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme_1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $__currentLoopData = $theme_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($a < 6): ?>
					<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
					margin-top: 0px; height: 272px;">
						
						<a href="details/mystery/<?php echo e($item_1->id); ?>">
							<img src="<?php echo e($item_1->Image); ?>" style="margin-left: 0px; 
							width: 200px;">
						</a>

						<div>
							<b><center><?php echo e($item_1->Name); ?></center></b>
						</div>
					</div>
				<?php endif; ?>
				<div style="display: none;"><?php echo e($a++); ?></div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div><br><br>
</div>

<div style="display: none;"><?php echo e($b=1); ?></div>

<div style="margin-top: 30px;">
	<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
		<?php $__currentLoopData = $romance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme_2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $__currentLoopData = $theme_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($b < 6): ?>
					<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
					margin-top: 0px; height: 272px;">
						
						<a href="details/romance/<?php echo e($item_2->id); ?>">
							<img src="<?php echo e($item_2->Image); ?>" style="margin-left: 0px; 
							width: 200px;">
						</a>

						<div>
							<b><center><?php echo e($item_2->Name); ?></center></b>
						</div>
					</div>
				<?php endif; ?>
				<div style="display: none;"><?php echo e($b++); ?></div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div><br><br>
</div>

<div style="display: none;"><?php echo e($c=1); ?></div>

<div style="margin-top: 30px;">
	<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
		<?php $__currentLoopData = $sci_fi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme_3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $__currentLoopData = $theme_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($c < 6): ?>
					<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
					margin-top: 0px; height: 272px;">
						
						<a href="details/sci_fi/<?php echo e($item_3->id); ?>">
							<img src="<?php echo e($item_3->Image); ?>" style="margin-left: 0px; 
							width: 200px;">
						</a>

						<div>
							<b><center><?php echo e($item_3->Name); ?></center></b>
						</div>
					</div>
				<?php endif; ?>
				<div style="display: none;"><?php echo e($c++); ?></div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div><br><br>
</div>

<div style="display: none;"><?php echo e($d=1); ?></div>

<div style="margin-top: 30px;">
	<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
		<?php $__currentLoopData = $biz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme_4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $__currentLoopData = $theme_4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($d < 6): ?>
					<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
					margin-top: 0px; height: 272px;">
						
						<a href="details/biz/<?php echo e($item_4->id); ?>">
							<img src="<?php echo e($item_4->Image); ?>" style="margin-left: 0px; 
							width: 200px;">
						</a>

						<div>
							<b><center><?php echo e($item_4->Name); ?></center></b>
						</div>
					</div>
				<?php endif; ?>
				<div style="display: none;"><?php echo e($d++); ?></div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div><br><br>
</div>

<div style="display: none;"><?php echo e($e=1); ?></div>

<div style="margin-top: 30px;">
	<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
		<?php $__currentLoopData = $mot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme_5): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $__currentLoopData = $theme_5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_5): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($e < 6): ?>
					<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
					margin-top: 0px; height: 272px;">
						
						<a href="details/mot/<?php echo e($item_5->id); ?>">
							<img src="<?php echo e($item_5->Image); ?>" style="margin-left: 0px; 
							width: 200px;">
						</a>

						<div>
							<b><center><?php echo e($item_5->Name); ?></center></b>
						</div>
					</div>
				<?php endif; ?>
				<div style="display: none;"><?php echo e($e++); ?></div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div><br><br>
</div>

<div style="display: none;"><?php echo e($f=1); ?></div>

<div style="margin-top: 30px;">
	<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
		<?php $__currentLoopData = $bio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme_6): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $__currentLoopData = $theme_6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_6): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($f < 6): ?>
					<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
					margin-top: 0px; height: 272px;">
						
						<a href="details/bio/<?php echo e($item_6->id); ?>">
							<img src="<?php echo e($item_6->Image); ?>" style="margin-left: 0px; 
							width: 200px;">
						</a>

						<div>
							<b><center><?php echo e($item_6->Name); ?></center></b>
						</div>
					</div>
				<?php endif; ?>
				<div style="display: none;"><?php echo e($f++); ?></div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div><br><br>
</div>

<div style="display: none;"><?php echo e($g=1); ?></div>

<div style="margin-top: 30px;">
	<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
		<?php $__currentLoopData = $mag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme_7): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $__currentLoopData = $theme_7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_7): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($g < 6): ?>
					<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
					margin-top: 0px; height: 272px;">
						
						<a href="details/mag/<?php echo e($item_7->id); ?>">
							<img src="<?php echo e($item_7->Image); ?>" style="margin-left: 0px; 
							width: 200px;">
						</a>

						<div>
							<b><center><?php echo e($item_7->Name); ?></center></b>
						</div>
					</div>
				<?php endif; ?>
				<div style="display: none;"><?php echo e($g++); ?></div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div><br><br>
</div>

<div style="display: none;"><?php echo e($h=1); ?></div>

<div style="margin-top: 30px;">
	<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
		<?php $__currentLoopData = $new_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme_8): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $__currentLoopData = $theme_8; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_8): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($h < 6): ?>
					<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
					margin-top: 0px; height: 272px;">
						
						<a href="details/new_arr/<?php echo e($item_8->id); ?>">
							<img src="<?php echo e($item_8->Image); ?>" style="margin-left: 0px; 
							width: 200px;">
						</a>

						<div>
							<b><center><?php echo e($item_8->Name); ?></center></b>
						</div>
					</div>
				<?php endif; ?>
				<div style="display: none;"><?php echo e($h++); ?></div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div><br><br>
</div><?php /**PATH D:\xampp\htdocs\Book_Store\resources\views/search.blade.php ENDPATH**/ ?>