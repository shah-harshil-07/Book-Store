<html>
<head>
	<title>Change Password</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <style>
        body
        {
            background-image: url('https://i.pinimg.com/originals/73/77/cf/7377cf3bb5b747377c6b1f583da22299.jpg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%; 	
        }
		::placeholder
		{
			color: #ff0000 !important;
			font-weight: bold;
		}
    </style>
</head>
<body class="container">

    <div style="display: none;">
        <?php if(Session::has("pass")): ?>
        {
            <?php echo "<script>alert('Both the passwords do not match.');</script>"; ?>
        }
        <?php endif; ?>
    </div>
    
	<div style="border: 2px solid black; margin-top: 100px; height: 250px;
        width: 500px; margin-left: 270px;">

 		<h1 style="text-align: center; margin-top: 20px;" >CHANGE PASSWORD</h1>
 		
 		<form class="form was-validated" method="POST" action="alt_pass">
			<?php echo csrf_field(); ?>
            <?php echo method_field("PUT"); ?>
	 		<p class="form-group">
	 			<input type="text" name="pass_1" placeholder="Enter New Password" 
                 class="form-control col-sm-10" required="Please fill out this field" 
                 style="margin-left: 40px; background: rgba(0,0,0,0);">
	 		</p>
	 		
	 		<p class="form-group">
	 			<input type="password" name="pass_2" placeholder="Enter Confirmed Password" 
                 class="form-control col-sm-10" required="Please fill out this field" 
                 style="margin-left: 40px; background: rgba(0,0,0,0);">
	 		</p>
	 		
	 		<p class="form-group;">
	 			<input type="submit" name="submit" class="btn btn-secondary col-sm-10" 
                 style="margin-left: 40px;" value="Submit">
	 		<p>
 		</form>
	</div>
</body>
</html><?php /**PATH D:\xampp\htdocs\BookStore\resources\views/Accounts/alt_pass.blade.php ENDPATH**/ ?>