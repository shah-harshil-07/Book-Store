<?php echo $__env->make("layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<h2 style="margin-top: 30px;">Top 12 collection of romance books</h2>
	<div class="card" style="width: 300px; height: 400px;">
		<img src="https://m.media-amazon.com/images/I/51b65pfpGXL._SX260_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-danger text-white" style="text-align: center">
			<h4 class="card-title">A Modern Romance</h4>
			<p class="card-text">By Sherrie Lynn</p>
			<a href="details/romance/1">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 350px; margin-top: -400px; height: 400px;">
		<img src="https://images-eu.ssl-images-amazon.com/images/I/41nAzKvvQ5L._SY264_BO1,204,203,200_QL40_FMwebp_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-danger text-white" style="text-align: center">
			<h4 class="card-title">Our Love Story</h4>
			<p class="card-text">By Rohit Sharma</p>
			<a href="details/romance/2">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 700px; margin-top: -400px; height: 400px;">
		<img src="https://m.media-amazon.com/images/I/41LlVlyLfKL.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-danger text-white" style="text-align: center">
			<h5 class="card-title">Until Love Sets Us Apart</h5>
			<p class="card-text">By Aditya Nighhot</p>
			<a href="details/romance/3">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 1050px; margin-top: -400px; height: 400px;">
		<img src="https://images-eu.ssl-images-amazon.com/images/I/4167MIN89rL._SY264_BO1,204,203,200_QL40_FMwebp_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-danger text-white" style="text-align: center">
			<h6 class="card-title">Let me go: To friendship with love</h6>
			<p class="card-text">By Shriram Iyer</p>
			<a href="details/romance/4">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-top: 30px; height: 400px;">
		<img src="https://images-eu.ssl-images-amazon.com/images/I/51UkTYa2n3L._SY264_BO1,204,203,200_QL40_FMwebp_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-danger text-white" style="text-align: center">
			<h5 class="card-title">When the Chief fell in Love</h5>
			<p class="card-text">By Tuhin A. Sinha</p>
			<a href="details/romance/5">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 350px; margin-top: -400px">
		<img src="https://images-eu.ssl-images-amazon.com/images/I/51IA4PSfp7L._SY264_BO1,204,203,200_QL40_FMwebp_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-danger text-white" style="text-align: center">
			<h4 class="card-title">Lost in Love</h4>
			<p class="card-text">By Arvind Parashar</p>
			<a href="details/romance/6">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 700px; margin-top: -400px">
		<img src="https://images-na.ssl-images-amazon.com/images/I/410PsDCzjFL._SX328_BO1,204,203,200_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-danger text-white" style="text-align: center">
			<h4 class="card-title">The Girl in Room 105</h4>
			<p class="card-text">By Chetan Bhagat</p>
			<a href="details/romance/7">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 1050px; margin-top: -400px">
		<img src="https://images-na.ssl-images-amazon.com/images/I/51O3qBc4Q6L._SX320_BO1,204,203,200_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-danger text-white" style="text-align: center">
			<h5 class="card-title">The Lover In My Dreams</h5>
			<p class="card-text">By Shivani Singhal</p>
			<a href="details/romance/8">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-top: 30px;">
		<img src="https://images-eu.ssl-images-amazon.com/images/I/51wnYZiXLcL._SY264_BO1,204,203,200_QL40_FMwebp_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-danger text-white" style="text-align: center">
			<h4 class="card-title">The Girl Next Door</h4>
			<p class="card-text">By Arpit Vageria</p>
			<a href="details/romance/9">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 350px; margin-top: -400px">
		<img src="https://images-eu.ssl-images-amazon.com/images/I/512ZvfnSMOL._SY264_BO1,204,203,200_QL40_FMwebp_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-danger text-white" style="text-align: center">
			<h5 class="card-title">The One from the Stars</h5>
			<p class="card-text">By Keshav Aneel</p>
			<a href="details/romance/10">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 700px; margin-top: -400px">
		<img src="https://images-na.ssl-images-amazon.com/images/I/513MR0RUBrL._SX322_BO1,204,203,200_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-danger text-white" style="text-align: center">
			<h4 class="card-title">That Kiss in the Rain</h4>
			<p class="card-text">By Novoneel Chakraborty</p>
			<a href="details/romance/11">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 1050px; margin-top: -400px">
		<img src="https://images-eu.ssl-images-amazon.com/images/I/51SW6zOpxcL._SY264_BO1,204,203,200_QL40_FMwebp_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-danger text-white" style="text-align: center">
			<h4 class="card-title">It's All in the Planets</h4>
			<p class="card-text">By Preeti Shenoy</p>
			<a href="details/romance/12">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
<?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\BookStore\resources\views/Theme_Page/Product_romance.blade.php ENDPATH**/ ?>