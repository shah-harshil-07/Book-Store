<html>
<head>
	<title>Product Page</title>

	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

	<style>
		img
		{
			width: 160px;
			height: 190px;
			margin-left: 50px;
		}
		.mag
		{
			margin-left: 0px;
			width: 1400px;
			height: 300px;
		}
		.theme
		{
			width: 400px;
			height: 70px;
			margin-left: 30px;
			margin-top: 10px;
		}
		body
		{
			background-image: url('https://i.pinimg.com/originals/73/77/cf/7377cf3bb5b747377c6b1f583da22299.jpg');
			background-repeat: no-repeat;
			background-attachment: fixed;
			background-size: 100% 100%; 	
		}
		.crd-img
        {
            width: 298px;
            height: 260px;
            margin-left: 90px;
            margin-top: 20px;
        }
	</style>
    <body class="container-fluid">
		<header class="header" style="width: 100%; height: 11%; background-color: black; 
		opacity: 0.7">
			<div>	
				<h2 style="padding-top: 10px;">Hello <?php echo e(session("user")); ?></h2>
				<form action="GET" style="margin-left: 220px; margin-top: -40px;">
					<input type="search" class="col-xl-6" placeholder="Type name of any book">
					<input type="submit" value="Search" class="btn btn-outline-light">
				</form>

				<a href="/acc_set">
					<button class="btn btn-outline-light col-md-1" style="margin-left: 920px; 
					margin-top: -62px;">
						<i class='fas fa-cog'></i> Account settings
					</button>
				</a>

				<button class="btn btn-outline-light col-md-1" style="margin-left: 1060px; 
				margin-top: -62px;">Returns & Orders</button>
				
				<a href="/logout">
					<button class="btn btn-outline-light col-md-1" style="margin-left: 1230px; 
					margin-top: -62px;">
						Login / Logout
					</button>
				</a>
			</div>
		</header>
<?php echo $__env->yieldSection(); ?><?php /**PATH D:\xampp\htdocs\BookStore\resources\views/layout/master.blade.php ENDPATH**/ ?>