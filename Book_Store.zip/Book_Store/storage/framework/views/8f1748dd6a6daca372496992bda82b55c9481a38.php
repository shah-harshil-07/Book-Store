<?php echo $__env->make("layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <img src="<?php echo e($item->Image); ?>" style="width: 300px; 
                height: 300px; margin-top: 30px; margin-left: 0px;">
            </div>
            <div style="margin-left: 350px; margin-top: -300px;">
                <h1><?php echo e($item->Name); ?></h1> 
                <p>By <b><?php echo e($item->Author); ?></b></p><br>
                <p>Original Price: <b>₹<?php echo e($item->Price); ?></b></p>
                <p>18% CGST: <b>₹<?php echo e(0.18*$item->Price); ?></b></p>
                <p>Total Price: <b>₹<?php echo e($item->Price + 0.18*$item->Price); ?></b></p>
                <button class="btn btn-outline-primary">Add to Library</button>
                <button class="btn btn-outline-success ml-4">Order Now</button>
            </div>
            <div style="margin-top: 50px;">
                <h2>Book Description</h2>
                <?php echo e($item->Description); ?>

            </div>
            <div style="margin-top: 50px;">
                <h2>Other details of book</h2>
                <p><b>Publisher:</b> <?php echo e($item->Publisher); ?></p>
                <p><b>Publication Date:</b> <?php echo e($item->Publish_date); ?></p>
                <p><b>No. of pages:</b> <?php echo e($item->Print_Length); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\BookStore\resources\views/Details_Page.blade.php ENDPATH**/ ?>