<?php echo $__env->make("layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<h2 style="margin-top: 30px;">Top 12 collection of mystery books</h2>
	<div class="card" style="width: 300px; height: 400px;">
		<img src="https://images-na.ssl-images-amazon.com/images/I/414W1uSUGdS._SX460_BO1,204,203,200_.jpg" 
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-dark text-white" style="text-align: center">
			<h4 class="card-title">Gone in the Wind</h4>
			<p class="card-text">By Margaret Mitchell</p>
			<a href="details/mystery/1">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 350px; margin-top: -400px; height: 400px;">
		<img src="https://images-na.ssl-images-amazon.com/images/I/41QMKIWimFL._SX311_BO1,204,203,200_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-dark text-white" style="text-align: center">
			<h4 class="card-title">The Perfect Murder</h4>
			<p class="card-text">By Ruskin Bond</p>
			<a href="details/mystery/2">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 700px; margin-top: -400px; height: 400px;">
		<img src="https://m.media-amazon.com/images/I/41ArKWcubgS.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-dark text-white" style="text-align: center">
			<h5 class="card-title">The Woman in the Window</h5>
			<p class="card-text">By A. J. Finn</p>
			<a href="details/mystery/3">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 1050px; margin-top: -400px; height: 400px;">
		<img src="https://m.media-amazon.com/images/I/41r7LYtp8jL.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-dark text-white" style="text-align: center">
			<h6 class="card-title">The Murder on the Links (Poirot)</h6>
			<p class="card-text">By Agatha Christie</p>
			<a href="details/mystery/4">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-top: 30px; height: 400px;">
		<img src="https://images-na.ssl-images-amazon.com/images/I/51HBfGa3+7L._SY344_BO1,204,203,200_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-dark text-white" style="text-align: center">
			<h4 class="card-title">The Secret of Old Clock</h4>
			<p class="card-text">By Carolyn Keene</p>
			<a href="details/mystery/5">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 350px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/41VcKWki1OL.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-dark text-white" style="text-align: center">
			<h4 class="card-title">Murder in the Crypt</h4>
			<p class="card-text">By Irina Shapiro</p>
			<a href="details/mystery/12">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 700px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/51QptpSXuhS.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-dark text-white" style="text-align: center">
			<h4 class="card-title">Pieces of Her</h4>
			<p class="card-text">By Robert J. Walker</p>
			<a href="details/mystery/6">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 1050px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/51pLB0SCsjL.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-dark text-white" style="text-align: center">
			<h4 class="card-title">Neelkanth</h4>
			<p class="card-text">By Satyam Shrivastava, Rajeev Garg</p>
			<a href="details/mystery/7">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-top: 30px;">
		<img src="https://images-na.ssl-images-amazon.com/images/I/51Id2bAxt9L._SX329_BO1,204,203,200_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-dark text-white" style="text-align: center">
			<h4 class="card-title">The Silent Patient</h4>
			<p class="card-text">By Alex Michaelides</p>
			<a href="details/mystery/8">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 350px; margin-top: -400px">
		<img src="https://images-na.ssl-images-amazon.com/images/I/51+kE0KESsL._SX326_BO1,204,203,200_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-dark text-white" style="text-align: center">
			<h5 class="card-title">And Then There Were None</h5>
			<p class="card-text">By Agatha Christie</p>
			<a href="details/mystery/9">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 700px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/71LyzYMAQ3L._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-dark text-white" style="text-align: center">
			<h5 class="card-title">Psychopath, Cannibal, Lover</h5>
			<p class="card-text">By Tejaswi Priyadarshi</p>
			<a href="details/mystery/10">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 1050px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/71offzgiZCL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-dark text-white" style="text-align: center">
			<h5 class="card-title">3 and a Half Murders</h5>
			<p class="card-text">By Salil Desai</p>
			<a href="details/mystery/11">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
<?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\Book_Store\resources\views/Theme/Product_mystery.blade.php ENDPATH**/ ?>