<?php echo $__env->make("layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1 style="margin-top: 30px;">Your Library</h1>
<div style="margin-top: 30px;">
    <b style="margin-left: 100px; font-size: 18;">Book</b>
    <b style="margin-left: 160px; font-size: 18;">Details</b>
    <b style="margin-left: 860px; font-size: 18;">Price</b>
</div>
<hr>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $theme; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <img src="<?php echo e($detail->Image); ?>">
        <div style="margin-left: 300px; margin-top: -190px;">
            <p>
                <b><?php echo e($detail->Name); ?></b>
                <div style="margin-left: 930px; margin-top: -40px;"><b>₹<?php echo e($detail->Price); ?></b></div>
            </p>
            <p>by <b><?php echo e($detail->Author); ?></b></p>
            <p class="form-group col-md-2" style="margin-left: -15px;">
                <label for="Quantity"><b>Quantity</b></label>
                <select name="Quantity" id="Quantity" class="form-control col-sm-5" 
                style="margin-left: 80px; margin-top: -40px;">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                </select>
            </p>
            <p style="margin-top: 20px;">
                <button class="btn btn-outline-danger">Delete from library</button>
                <button class="btn btn-outline-success ml-3">Order Now</button>
            </p>
            <p style="margin-top: 20px;">
                <a href="/details/<?php echo e($detail->Theme); ?>/<?php echo e($detail->Product_id); ?>">Details</a>
            </p>
        </div>
        <hr style="margin-top: 30px;">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\BookStore\resources\views/Cart_&_Orders/cart.blade.php ENDPATH**/ ?>