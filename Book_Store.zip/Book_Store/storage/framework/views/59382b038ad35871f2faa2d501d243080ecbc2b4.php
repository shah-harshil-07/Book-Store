<?php echo $__env->make("layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="/order_product/<?php echo e($theme); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <h2 class="mt-4">Choose a way to pay ₹<?php echo e($data['Quantity'] * 0.88 * $data['product_price']); ?></h2>
        <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="<?php echo e($item_1->Image); ?>"
            style="width: 250px; height: 250px; margin-left: 0px;">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div style="margin-left: 300px; margin-top: -250px; width: 290px;">
            <div>
                <p><b><?php echo e($data['product_name']); ?></b></p>
                <p>by <b><?php echo e($data['product_author']); ?></b></p>
                <p>
                    Quantity: <input type="number" readonly value="<?php echo e($data['Quantity']); ?>" 
                    style="background: rgba(0,0,0,0); border: none; font-weight: bold;" 
                    name="product_quantity" class="col-sm-3">
                </p>
                <p>
                    Total Price(GST inclusive)(₹): 
                    <b>
                        <?php echo e(($data['Quantity']*$data['product_price']) + ($data['Quantity']*$data['product_price']*0.18)); ?>

                    </b>
                </p>
                <p>
                    Discount of 30%(₹): 
                    <b>-<?php echo e(0.3 * $data['Quantity'] * $data['product_price']); ?></b>
                </p>
                <p>
                    Total amount payable(₹): 
                    <input type="number" readonly value="<?php echo e($data['Quantity'] * 0.88 * $data['product_price']); ?>" 
                    style="background: rgba(0,0,0,0); border: none; font-weight: bold;" 
                    name="product_total_cost" class="col-sm-4">
                </p>
            </div>
        </div>
        
        <div class="form-group" style="margin-left: 620px; margin-top: -250px;">
            <h2>Payment options</h2>
            <div class="form-check">
                <label for="UPI" class="form-check-label mt-3">
                    <input type="radio" class="form-check-input" value="UPI" name="pay" checked>UPI
                </label>
            </div>
            <div class="form-check">
                <label for="Add a Credit, Debit or ATM card" class="form-check-label mt-3">
                    <input type="radio" class="form-check-input" value="Card"
                    name="pay">
                    Add a Credit, Debit or ATM card
                </label>
            </div>
            <div class="form-check">
                <label for="Net Banking" class="form-check-label mt-3">
                    <input type="radio" class="form-check-input" value="Net Banking" name="pay">
                    Net Banking
                </label>
            </div> 
            <div class="form-check">
                <label for="Cash On Delivery" class="form-check-label mt-3">
                    <input type="radio" class="form-check-input" value="Cash On Delivery" name="pay">
                    Cash on Delivery
                </label>
            </div>  
        </div>

        <?php $__currentLoopData = $address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="margin-top: 80px;">
                <p><b>Deliver to:</b></p> 
                    <input type="text" name="address" style="width: 650px; height: 100px;" 
                    value="<?php echo e($item_2->Apartment); ?>, <?php echo e($item_2->Street); ?>, <?php echo e($item_2->City); ?>, <?php echo e($item_2->State); ?>.">
            </div><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <div style="display: none;">
            <input type="number" value="<?php echo e($item_1->id); ?>" name="product_id">
        </div>

        <input type="submit" value="Place order" class="btn btn-outline-success">
    </form>
<?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\Book_Store\resources\views/Cart_&_Orders/orders.blade.php ENDPATH**/ ?>