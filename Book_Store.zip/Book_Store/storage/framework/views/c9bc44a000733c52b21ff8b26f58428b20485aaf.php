<html>
    <head>
        <title>E Bill</title>

        <meta charset="utf-8">
  	    <meta name="viewport" content="width=device-width, initial-scale=1">
  	    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  	    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  	    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

        <style>
            body
		    {
			    background-image: url('https://i.pinimg.com/originals/73/77/cf/7377cf3bb5b747377c6b1f583da22299.jpg');
			    background-repeat: no-repeat;
			    background-attachment: fixed;
			    background-size: 100% 100%; 	
		    }
        </style>
    </head>

    <body class="container">
        <h3>User Information</h3>
        <?php $__currentLoopData = $user_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><b>User id:</b> <?php echo e($user->id); ?></p>
            <p><b>User Name:</b> <?php echo e($user->First_Name); ?> <?php echo e($user->Last_Name); ?></p>
            <p><b>User Email id:</b> <?php echo e($user->Email); ?></p>
            <p>
                <b>Residential Address: </b>
                <?php echo e($user->Apartment); ?>, <?php echo e($user->Street); ?>, <?php echo e($user->City); ?>, <?php echo e($user->State); ?>.
            </p><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <h3>Order Information</h3>
        <?php $__currentLoopData = $order_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><b>Order Quantity:</b> <?php echo e($order->Quantity); ?></p>
            <p><b>Order Total Amount Paid:</b> <?php echo e($order->Total_Cost); ?></p>
            <p><b>Order Payment Method:</b> <?php echo e($order->Payment_Method); ?></p>
            <p><b>Order Delivery Address: </b><?php echo e($order->Delivery_Address); ?></p><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <h3>Product Information</h3>
        <?php $__currentLoopData = $product_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><b>Product id:</b> <?php echo e($order->Product_id); ?></p>
            <p><b>Product Theme:</b> <?php echo e($order->Theme); ?></p>
            <p><b>Product Name:</b> <?php echo e($product->Name); ?></p>
            <p><b>Product Author:</b> <?php echo e($product->Author); ?></p>
            <p><b>Product Price per piece:</b> <?php echo e($product->Price); ?></p>
            <p><b>Product's no. of pages:</b> <?php echo e($product->Print_Length); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </body>
</html><?php /**PATH D:\xampp\htdocs\Book_Store\resources\views/Cart_&_Orders/e_bill.blade.php ENDPATH**/ ?>