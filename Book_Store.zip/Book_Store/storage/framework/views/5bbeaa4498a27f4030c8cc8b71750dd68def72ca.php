<?php echo $__env->make("layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<h2 style="margin-top: 30px;">Top 8 collection of science fiction books</h2>
	<div class="card" style="width: 300px; height: 400px;">
		<img src="https://images-eu.ssl-images-amazon.com/images/I/51YShNPRZuL._SY264_BO1,204,203,200_QL40_FMwebp_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-info text-white" style="text-align: center">
			<h4 class="card-title">The Invisible Man</h4>
			<p class="card-text">By H. G. Wells</p>
			<a href="details/sci_fi/1">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 350px; margin-top: -400px; height: 400px;">
		<img src="https://images-na.ssl-images-amazon.com/images/I/51YP7fM361S._SX460_BO1,204,203,200_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-info text-white" style="text-align: center">
			<h4 class="card-title">The Time Machine</h4>
			<p class="card-text">By H. G. Wells</p>
			<a href="details/sci_fi/2">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 700px; margin-top: -400px; height: 400px;">
		<img src="https://images-na.ssl-images-amazon.com/images/I/41AAGjfxB2L._SX321_BO1,204,203,200_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-info text-white" style="text-align: center">
			<h4 class="card-title">The Midwich Cuckoos</h4>
			<p class="card-text">By John Wyndham</p>
			<a href="details/sci_fi/3">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 1050px; margin-top: -400px; height: 400px;">
		<img src="https://m.media-amazon.com/images/I/51kmRnNeurL._SY346_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-info text-white" style="text-align: center">
			<h4 class="card-title">The Seeds of Time</h4>
			<p class="card-text">By John Wyndham</p>
			<a href="details/sci_fi/4">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-top: 30px; height: 400px;">
		<img src="https://m.media-amazon.com/images/I/51UsAkUwBgL.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-info text-white" style="text-align: center">
			<h5 class="card-title">The Death of the Universe</h5>
			<p class="card-text">By Brandon Q. Morris</p>
			<a href="details/sci_fi/5">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 350px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/41-oIoxD4AL.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-info text-white" style="text-align: center">
			<h4 class="card-title">Post-Human Omnibus</h4>
			<p class="card-text">By David Simpson</p>
			<a href="details/sci_fi/6">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 700px; margin-top: -400px">
		<img src="https://images-eu.ssl-images-amazon.com/images/I/61pxmY0HlbL._SY264_BO1,204,203,200_QL40_FMwebp_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-info text-white" style="text-align: center">
			<h4 class="card-title">Dark Matter</h4>
			<p class="card-text">By Blake Crouch</p>
			<a href="details/sci_fi/7">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 1050px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/41eDMK+5cIL.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-info text-white" style="text-align: center">
			<h4 class="card-title">The Other Side</h4>
			<p class="card-text">By Adway</p>
			<a href="details/sci_fi/8">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
<?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\Book_Store\resources\views/Theme/Product_sci.blade.php ENDPATH**/ ?>