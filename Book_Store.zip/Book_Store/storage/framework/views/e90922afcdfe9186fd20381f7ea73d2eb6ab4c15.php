<?php echo $__env->make("layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<h2 style="margin-top: 30px;">Top 12 collection of business books</h2>
	<div class="card" style="width: 300px; height: 400px;">
		<img src="https://images-na.ssl-images-amazon.com/images/I/51H+qSaPLrS._SY344_BO1,204,203,200_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-success text-white" style="text-align: center">
			<h5 class="card-title">Winning in the Digital Age</h5>
			<p class="card-text">By Nitin Seth</p>
			<a href="details/biz/1">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 350px; margin-top: -400px; height: 400px;">
		<img src="https://images-eu.ssl-images-amazon.com/images/I/51ZMRZdeXIL._SY264_BO1,204,203,200_QL40_FMwebp_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-success text-white" style="text-align: center">
			<h6 class="card-title">The Amazon Management System</h6>
			<p class="card-text">By Ram Charan</p>
			<a href="details/biz/2">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 700px; margin-top: -400px; height: 400px;">
		<img src="https://images-eu.ssl-images-amazon.com/images/I/41dym8cb0JL._SY264_BO1,204,203,200_QL40_FMwebp_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-success text-white" style="text-align: center">
			<h4 class="card-title">The 10X Rule</h4>
			<p class="card-text">By Grant Cardone</p>
			<a href="details/biz/3">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 1050px; margin-top: -400px; height: 400px;">
		<img src="https://images-eu.ssl-images-amazon.com/images/I/416ZmY24ORL._SY264_BO1,204,203,200_QL40_FMwebp_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-success text-white" style="text-align: center">
			<h4 class="card-title">Corporate Chanakya</h4>
			<p class="card-text">By Radhakrishnan Pillai</p>
			<a href="details/biz/4">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-top: 30px; height: 400px;">
		<img src="https://images-eu.ssl-images-amazon.com/images/I/413qubX-sKL._SY264_BO1,204,203,200_QL40_FMwebp_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-success text-white" style="text-align: center">
			<h4 class="card-title">Retailing Management</h4>
			<p class="card-text">By Michael Levy</p>
			<a href="details/biz/5">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 350px; margin-top: -400px">
		<img src="https://images-na.ssl-images-amazon.com/images/I/51yuqkCl37L._SX396_BO1,204,203,200_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-success text-white" style="text-align: center">
			<h6 class="card-title">Management Information System</h6>
			<p class="card-text">By Raj Sahil</p>
			<a href="details/biz/6">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 700px; margin-top: -400px">
		<img src="https://images-na.ssl-images-amazon.com/images/I/51oS6cuWN1L._SX396_BO1,204,203,200_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-success text-white" style="text-align: center">
			<h6 class="card-title">Options, Future & Derivatives</h6>
			<p class="card-text">By John C. Hull, Sankarshan Basu</p>
			<a href="details/biz/7">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 1050px; margin-top: -400px">
		<img src="https://images-na.ssl-images-amazon.com/images/I/51EVM8HOaKL._SX361_BO1,204,203,200_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-success text-white" style="text-align: center">
			<h5 class="card-title">E-Business and E-Commerce</h5>
			<p class="card-text">By Chaffey</p>
			<a href="details/biz/8">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-top: 30px;">
		<img src="https://m.media-amazon.com/images/I/91cZjXThBEL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-success text-white" style="text-align: center">
			<h6 class="card-title">Intro. to Financial Accounting</h6>
			<p class="card-text">By Charles, Gary, John, Danna</p>
			<a href="details/biz/9">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 350px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/51LdQJZPCuL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-success text-white" style="text-align: center">
			<h4 class="card-title">Corporate Accounting</h4>
			<p class="card-text">By Rajasekaran & Lalitha</p>
			<a href="details/biz/10">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 700px; margin-top: -400px">
		<img src="https://images-na.ssl-images-amazon.com/images/I/5179BO5K0tL._SX367_BO1,204,203,200_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-success text-white" style="text-align: center">
			<h6 class="card-title">Auditing: Principles and Techniques</h6>
			<p class="card-text">By Basu</p>
			<a href="details/biz/11">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 1050px; margin-top: -400px">
		<img src="https://images-eu.ssl-images-amazon.com/images/I/51JWnbJyL-L._SY264_BO1,204,203,200_QL40_FMwebp_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-success text-white" style="text-align: center">
			<h4 class="card-title">Think & Grow Rich</h4>
			<p class="card-text">By Napoleon Hill</p>
			<a href="details/biz/12">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>	
<?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\Book_Store\resources\views/Theme/Product_biz.blade.php ENDPATH**/ ?>