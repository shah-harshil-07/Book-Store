<?php echo $__env->make("layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<h2 style="margin-top: 30px;">Top 12 collection of biography books</h2>
	<div class="card" style="width: 300px; height: 400px;">
		<img src="https://m.media-amazon.com/images/I/81iUXe9ygkL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-secondary text-white" style="text-align: center">
			<h4 class="card-title">Elon Musk</h4>
			<p class="card-text">By Ashlee Vance</p>
			<a href="details/bio/1">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 350px; margin-top: -400px; height: 400px;">
		<img src="https://m.media-amazon.com/images/I/41n1edvVlLL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-secondary text-white" style="text-align: center">
			<h4 class="card-title">Steve Jobs</h4>
			<p class="card-text">By Walter Isaacson</p>
			<a href="details/bio/2">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 700px; margin-top: -400px; height: 400px;">
		<img src="https://m.media-amazon.com/images/I/91PzrveHByL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-secondary text-white" style="text-align: center">
			<h4 class="card-title">Adolf Hitler</h4>
			<p class="card-text">By Mamta Sharma Ghuge</p>
			<a href="details/bio/3">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 1050px; margin-top: -400px; height: 400px;">
		<img src="https://m.media-amazon.com/images/I/71gViT1Sl4L._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-secondary text-white" style="text-align: center">
			<h4 class="card-title">Leonardo da Vinci</h4>
			<p class="card-text">By Hourly History</p>
			<a href="details/bio/4">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-top: 30px; height: 400px;">
		<img src="https://m.media-amazon.com/images/I/912ByBNPaOL._AC_UL480_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-secondary text-white" style="text-align: center">
			<h4 class="card-title">The Tatas</h4>
			<p class="card-text">By Girish Kuber</p>
			<a href="details/bio/5">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 350px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/81rhxvqu9TL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-secondary text-white" style="text-align: center">
			<h4 class="card-title">My Life</h4>
			<p class="card-text">By Dr. Kalam, Prabhjyot Majithia</p>
			<a href="details/bio/6">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 700px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/71uENEGYG9L._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-secondary text-white" style="text-align: center">
			<h4 class="card-title">Thomas A. Edison</h4>
			<p class="card-text">By Hourly History</p>
			<a href="details/bio/7">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 1050px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/81WRW8X5exL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-secondary text-white" style="text-align: center">
			<h4 class="card-title">Nikola Tesla</h4>
			<p class="card-text">By Hourly History</p>
			<a href="details/bio/8">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-top: 30px;">
		<img src="https://m.media-amazon.com/images/I/71Dha8Gg3xL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-secondary text-white" style="text-align: center">
			<h4 class="card-title">Gautam Adani</h4>
			<p class="card-text">By Verity</p>
			<a href="details/bio/9">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 350px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/812auk0JlNL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-secondary text-white" style="text-align: center">
			<h4 class="card-title">Ambani & Sons</h4>
			<p class="card-text">By Hamish McDonald</p>
			<a href="details/bio/10">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 700px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/81-m2d9Ja6L._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-secondary text-white" style="text-align: center">
			<h4 class="card-title">Azim Premji</h4>
			<p class="card-text">By Sundeep Khanna</p>
			<a href="details/bio/11">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 1050px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/81AGhPSGLkL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-secondary text-white" style="text-align: center">
			<h4 class="card-title">The Truths We Hold</h4>
			<p class="card-text">By Kamala Harris</p>
			<a href="details/bio/12">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
<?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\BookStore\resources\views/Theme_Page/Product_bio.blade.php ENDPATH**/ ?>