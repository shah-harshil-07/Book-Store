<h2>Choose a way to pay ₹500</h2>
<img src="https://images-na.ssl-images-amazon.com/images/I/51H+qSaPLrS._SY344_BO1,204,203,200_.jpg"
style="width: 250px; height: 250px;">
<div style="margin-left: 300px; margin-top: -260px;">
    <div>
        <p>Book Name</p>
        <p>by <b>Author</b></p>
        <p>Price with GST: <b>₹500</b></p>
        <p>Discount of 30%: <b>₹20</b></p>
        <p>Total amount payable: <b>₹480</b></p>
    </div>
</div>

<form class="form-group" style="margin-top: 110px;">
    <h2>Payment options</h2>
    <div class="form-check">
        <label for="UPI" class="form-check-label">
            <input type="radio" class="form-check-input" value="UPI" name="pay" checked>UPI
        </label>
    </div>
    <div class="form-check">
        <label for="Add a Credit, Debit or ATM card" class="form-check-label">
            <input type="radio" class="form-check-input" value="Add a Credit, Debit or ATM card"
            name="pay">
            Add a Credit, Debit or ATM card
        </label>
    </div>
    <div class="form-check">
        <label for="Net Banking" class="form-check-label">
            <input type="radio" class="form-check-input" value="Net Banking" name="pay">
            Net Banking
        </label>
    </div>   
</form>

<div>
    Deliver to: 
        <textarea name="adress" id="address" cols="30" rows="10"></textarea>
</div><br><br>

<button class="btn btn-outline-success">Place your order</button><?php /**PATH D:\xampp\htdocs\BookStore\resources\views/Cart_&_Orders/orders.blade.php ENDPATH**/ ?>