<html>
    <head>
        <title>Products Page</title>
    </head>
    <body>
        <h2>From your library</h2>
        <h2>New Arrivals</h2>
        <img src="<?php echo e(asset('/images/Harry_Potter'.$article->image)); ?>" alt="" title="">
    </body>
</html><?php /**PATH D:\xampp\htdocs\BookStore\resources\views/products.blade.php ENDPATH**/ ?>