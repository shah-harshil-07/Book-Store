<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class sci_fi extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table("sci_fi")
            ->insert([
                "Image"=>"https://images-eu.ssl-images-amazon.com/images/I/51YShNPRZuL._SY264_BO1,204,203,200_QL40_FMwebp_.jpg",
                "Author"=>"H. G. Wells",
                "Price"=>110,
                "Description"=>"“In the night, he must have eaten and slept;
                for in the morning he was himself again, active,
                powerful, angry and malignant, prepared for his
                last great struggle against the world.”
                Griffin, an ingenious research scientist, develops a process that can render physical objects invisible. Having successfully performed it on himself, he soon realises that it is impossible to survive like this. and now this invisible man is desperate to reverse the process.
                Will Griffin be able to become visible again?
                Or
                Will his obsession for invisibility result in his doom?",
                "Publisher"=>"Fingerprint! Publishing",
                "Publish_date"=>"1 February 2017",
                "Print_Length"=>160    
        ]);
    }
}
