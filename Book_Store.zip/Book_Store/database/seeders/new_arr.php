<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class new_arr extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table("new_arr")
            ->insert([
                "Image"=>"https://m.media-amazon.com/images/I/61s3nWyyI1L._AC_UY327_FMwebp_QL65_.jpg",
                "Author"=>"Priyanka Chopra Jonas",
                "Price"=>630,
                "Description"=>"'I have always felt that life is a solitary journey, that we are each on a train, riding through our hours, our days, our years. We get on alone, we leave alone, and the decisions we made as we travel on the train are our responsibility alone.'
                In this thoughtful and revealing memoir, readers will accompany one of the world's most recognizable women on her journey of self-discovery. A remarkable life story rooted in two different worlds, Unfinished offers insights into Priyanka Chopra Jonas's childhood in India; her formative teenage years in the United States; and her return to India, where against all odds as a newcomer to the pageant world, she won the national and international beauty competitions that launched her global acting career. Whether reflecting on her nomadic early years or the challenges she's faced as she's doggedly pursued her calling, Priyanka shares her challenges and triumphs with warmth and honesty. The result is a book that is philosophical, sassy, inspiring, bold, and rebellious. Just like the author herself.
                From her dual-continent twenty-year-long career as an actor and producer to her work as a UNICEF Goodwill Ambassador, from losing her beloved father to cancer to marrying Nick Jonas, Priyanka Chopra Jonas's story will inspire readers around the world to gather their courage, embrace their ambitions, and commit to the hard work of following their dreams.
                ",
                "Publisher"=>"Viking",
                "Publish_date"=>"9 February 2021",
                "Print_Length"=>282
            ]);
    }
}
