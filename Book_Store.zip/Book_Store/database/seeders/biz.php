<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class biz extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table("biz")
            ->insert([
                "Image"=>"https://images-na.ssl-images-amazon.com/images/I/51H+qSaPLrS._SY344_BO1,204,203,200_.jpg",
                "Author"=>"Nitin Seth",
                "Price"=>580,
                "Description"=>"Nitin brings in this book his 25+ years of experience in leadership roles in world-class firms like Mckinsey and Fidelity and Digital natives like Flipkart and Incedo. He presents compelling insights and practical examples and answers key questions on how enterprises can win in the Digital Age:
                Why do firms fail at digital transformation?
                How are the rules of business changing in the digital age? What disruptive opportunities does digital present in various industries?
                How to best leverage the potential of digital technologies like AI and the Cloud?
                How do organizational capabilities and culture need to change?
                What new skills do leaders and young professionals need to build?
                Nitin brings clarity to the transformation process, breaking it down into seven building blocks and presenting how best to master them.",
                "Publisher"=>"Penguin Enterprise",
                "Publish_date"=>"24 February 2021",
                "Print_Length"=>544
        ]);
    }
}
