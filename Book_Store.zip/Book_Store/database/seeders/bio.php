<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class bio extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table("bio")
            ->insert([
                "Image"=>"https://m.media-amazon.com/images/I/81iUXe9ygkL._AC_UY327_FMwebp_QL65_.jpg",
                "Author"=>"Ashlee Vance",
                "Price"=>455,
                "Description"=>"South African born Elon Musk is the renowned entrepreneur and innovator behind PayPal, SpaceX, Tesla, and SolarCity. Musk wants to save our planet; he wants to send citizens into space, to form a colony on Mars; he wants to make money while doing these things; and he wants us all to know about it. He is the real-life inspiration for the Iron Man series of films starring Robert Downey Junior.
                The personal tale of Musk’s life comes with all the trappings one associates with a great, drama-filled story. He was a freakishly bright kid who was bullied brutally at school, and abused by his father. In the midst of these rough conditions, and the violence of apartheid South Africa, Musk still thrived academically and attended the University of Pennsylvania, where he paid his own way through school by turning his house into a club and throwing massive parties.",
                "Publisher"=>"Virgin Books",
                "Publish_date"=>"8 April 2016",
                "Print_Length"=>416
        ]);
    }
}
