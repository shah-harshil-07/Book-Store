<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class romance extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table("romance")
            ->insert([
                "Image"=>"https://m.media-amazon.com/images/I/51b65pfpGXL._SX260_.jpg",
                "Author"=>"Sherrie Lynn",
                "Price"=>740,
                "Description"=>"Three unique short stories that read like a full novel plus one bonus short from the Modern Romance series. Meet Shaleah Hart & Eddie Lancing...Eddie was her high school sweetheart but things didn't work out. Now years later He is back in town. Can Shaleah & Eddie find their way back to each other? Meet Tyre & The Twins. Tyre's luck start to change after meeting former police detective Breona Wells and her twin. Can they put their past behind them and find true love? Say hello to Soren & Tanis, old friends attempting to sort out their friendship in a changing world. A Dialog driven, Rhyming Romance. Fashion designer, Felicitee take a leap of faith after meeting billionaire, Ronan Baptiste. But will a college prank come back to haunt her and destroy any chance of happiness? Fun and flowing language made this collection a breeze to read. Description is vivid and dialogue is natural. Best of all, the characters are realistic and relatable. Good for readers of any age, who prefer tasteful to explicit.",
                "Publisher"=>"Lulu.com",
                "Publish_date"=>"24 June 2016",
                "Print_Length"=>104
        ]);
    }
}
