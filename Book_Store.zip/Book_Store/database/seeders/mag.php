<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class mag extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table("mag")
            ->insert([
                "Image"=>"https://api.time.com/wp-content/uploads/2018/12/time-person-of-the-year-joe-biden-kamala-harris-2020-cover.jpg",
                "Author"=>"TIME Magazine",
                "Price"=>200,
                "Description"=>"TIME’s Person of the Year over the course of nearly a century has been a measuring stick for where the world is and where it’s going. But how to make sense of 2020, a year without measure? A year marked by multiple crises, all at once, all over the world: A once-in-a-century plague. Brutal racial injustice. Glaring inequality. Apocalyptic wildfires. Democracy under fire.

                It was a particularly humbling year for the most powerful nation on earth—a wake-up call for those more accustomed to seeing America, despite its flaws, as a beacon for the world. The U.S. has seen by far the most confirmed cases of COVID-19 of any country, and some of the worst fatality rates. The killings of George Floyd, Breonna Taylor, Ahmaud Arbery, Tony McDade and many more brought about a reckoning with systemic racism, long overdue and extraordinary in scale. Economic inequality deepened. Almost 1 in 8 American adults reported that their household didn’t have enough to eat at some point in November. Devastating fires across the West Coast showed how unprepared we are for climate change. Conflicts over voting tallies and the science of wearing masks showed how divided we are even on basic facts.Joe Biden was elected President of the United States in the midst of an existential debate over what reality we inhabit. Perhaps the only thing Americans agree on right now is that the future of the country is at stake, even as they fiercely disagree about why. Dismissed as out of touch on the left and misrepresented as a socialist from his right, Biden stood his ground near the center and managed to thrive even as the social, digital and racial landscape around him shifted. With more than 51%, Biden won a higher percentage of the popular vote than any challenger to a presidential incumbent since Franklin Roosevelt in 1932. “What I got most criticized for was I said we had to unite America,” he told me in a conversation (masks off, 16 ft. apart) at his unofficial transition hub in Wilmington, Del., on Dec. 7. “I never came off that message in the primary or in the general election.” Whether America can be, or even wants to be, united is a question he will soon have to face.",
                "Publisher"=>"Independently Published",
                "Publish_date"=>"21 December, 2020",
                "Print_Length"=>78
            ]);
    }
}
