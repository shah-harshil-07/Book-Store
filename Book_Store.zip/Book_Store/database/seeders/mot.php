<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class mot extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table("mot")
            ->insert([
                "Image"=>"https://m.media-amazon.com/images/I/81zz6LqCreS._AC_UY327_FMwebp_QL65_.jpg",
                "Author"=>"Dale Carnegie",
                "Price"=>100,
                "Description"=>"If worry fills up your mind and you end up struggling to conquer it, this book is all you need!
                “The secret of being miserable
                is to have the leisure to bother about
                whether you are happy or not.”
                From the fundamental facts that one must know about worry to the techniques in analyzing it, this book introduces ways to prevent fatigue and worry and cultivate a mental attitude that will bring peace and happiness. it offers insights on how to break the worry habit and brings for you not only a magic formula for solving worry situations but a way to conquer it altogether.
                A result of his own experiences and realizations, Dale Carnegie’s How to Stop Worrying and Start Living has inspired many and helped them triumph over their worries. with timeless practical advice, this classic bestseller holds the power to change your future.",
                "Publisher"=>"Fingerprint! Publishing",
                "Publish_date"=>"1 August 2016",
                "Print_Length"=>368
        ]);
    }
}
