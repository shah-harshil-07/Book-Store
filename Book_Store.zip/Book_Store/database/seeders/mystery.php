<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class mystery extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table("mystery")
            ->insert([
                "Image"=>"https://images-na.ssl-images-amazon.com/images/I/414W1uSUGdS._SX460_BO1,204,203,200_.jpg",
                "Author"=>"Margaret Mitchell",
                "Price"=>480,
                "Description"=>"It’s April 1861. Georgia, southern United States.
                Scarlet O’Hara—the vivacious, narcissistic and pampered daughter of a plantation owner in Atlanta—in a fit of choleric contempt over rejection by her desired man, Ashley Wilkes, hurls a figurine against the wall. And behind the depths of the sofa, Rhett Butler is woken up from his nap.
                “You’re no gentleman, ” fires the southern belle.
                “And you’re no lady!” the rogue fires back.
                Scarlet, for vengeance, accepts the marriage proposal from Charles Hamilton—Ashley Wilke’s brand new brother-in-law. But at the outbreak of the American Civil War he joins the army and dies of pneumonia followed by measles, a not-so-gallantry death. Through wiles and widowhood, Scarlet manages to keep her independence and becomes an astute business woman.
                Rhett Butler—the dark, flashy and scandalous visitor from Charleston—who is a professional gambler and blockade runner, is enamoured by her survival instincts.
                Around the social turmoils of the war, what becomes of O’Hara and Rhett Butler, an outcast whom she marries for money?",
                "Publisher"=>"Fingerprint! Publishing",
                "Publish_date"=>"1 August 2018",
                "Print_Length"=>952
            ]);
    }
}
