<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMysteryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('mystery', function (Blueprint $table) {
            $table->id();
            $table->string("Image");
            $table->string("Author");
            $table->integer("Price");
            $table->string("Description");
            $table->string("Publisher");
            $table->string("Publish_date");
            $table->integer("Print_Length");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('mystery');
    }
}
