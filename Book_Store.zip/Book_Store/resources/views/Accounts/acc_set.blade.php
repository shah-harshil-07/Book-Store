<!DOCTYPE html>
<html>
    <head>
        <title>Account Settings</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <style>
            body
            {
                background-image: url('https://i.pinimg.com/originals/73/77/cf/7377cf3bb5b747377c6b1f583da22299.jpg');
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: 100% 100%; 	
            }
            ::placeholder
            {
                color: #ff0000 !important;
                font-weight: bold;
            }
        </style>
    </head>
    <body class="container">

        <div style="border: 2px solid black; margin-top: 60px; height: 600px; width: 500px;
            margin-left: 300px;">

            <div style="margin-left: 30px; margin-top: -30px; margin-bottom: 100px; 
                margin-right: 30px;" class="was-validated">

                <h1 style="margin-top: 40px; text-align: center">ACCOUNT SETTINGS</h1>

                <p style="text-align: center; color: red">Following are your account details</p>

                <form class="form-group col-md-12" method="POST" action="acc_update">
                    @csrf
                    @method("PUT")
                    @foreach($data as $item)
                        @csrf
                        <p>
                            <input type="text" name="fname" placeholder="FIRST NAME" 
                            class="form-control" required="Please fill out this field" 
                            style="background: rgba(0,0,0,0);" value='{{$item->First_Name}}'>
                        </p>

                        <p>
                            <input type="text" name="lname" placeholder="LAST NAME" 
                            class="form-control" required="Please fill out this field"
                            style="background: rgba(0,0,0,0);" value='{{$item->Last_Name}}'>
                        </p>

                        <p>
                            <input type="text" name="email" placeholder="EMAIL ADDRESS" 
                            class="form-control" required="Please fill out this field"
                            style="background: rgba(0,0,0,0);" value='{{$item->Email}}'>
                        </p>

                        <p>
                            <input type="text" name="apt" placeholder="APT. NO./NAME WITH SOCIETY NAME" 
                            class="form-control" required="Please fill out this field" 
                            style="background: rgba(0,0,0,0);" value='{{$item->Apartment}}'>
                        </p>

                        <p>
                            <input type="text" name="street" placeholder="STREET NAME" 
                            class="form-control" required="Please fill out this field"
                            style="background: rgba(0,0,0,0);" value='{{$item->Street}}'>
                        </p>

                        <p>
                            <input type="text" name="city" placeholder="CITY NAME" 
                            class="form-control" required="Please fill out this field"
                            style="background: rgba(0,0,0,0);" value='{{$item->City}}'>
                        </p>

                        <p>
                            <input type="text" name="state" placeholder="STATE NAME" 
                            class="form-control" required="Please fill out this field"
                            style="background: rgba(0,0,0,0);" value='{{$item->State}}'>
                        </p>
                        
                        <p>
                            <input type="submit" name="submit" class="btn btn-secondary 
                            col-md-12" value="Update Account">
                        </p>
                    @endforeach
                </form>
                <p style="text-align: center;">
                    <a href="alt_pass">Change the Password</a>
                </p>
            </div>
        </div>
    </body>
</html>