@include("layout.master")
	<h2 style="margin-top: 30px;">Top 12 collection of motivational books</h2>
	<div class="card" style="width: 300px; height: 400px;">
		<img src="https://m.media-amazon.com/images/I/81zz6LqCreS._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-warning text-white" style="text-align: center">
			<h6 class="card-title">Stop worrying and start living</h6>
			<p class="card-text">By Dale Carnegie</p>
			<a href="details/mot/1">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 350px; margin-top: -400px; height: 400px;">
		<img src="https://m.media-amazon.com/images/I/710jnzKlDTL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-warning text-white" style="text-align: center">
			<h4 class="card-title">Attitude Is Everything</h4>
			<p class="card-text">By Jeff Keller</p>
			<a href="details/mot/2">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 700px; margin-top: -400px; height: 400px;">
		<img src="https://m.media-amazon.com/images/I/71eijJe2ntL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-warning text-white" style="text-align: center">
			<h4 class="card-title">The 5 AM Club</h4>
			<p class="card-text">By Robin Sharma</p>
			<a href="details/mot/3">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-left: 1050px; margin-top: -400px; height: 400px;">
		<img src="https://m.media-amazon.com/images/I/81cpDaCJJCL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-warning text-white" style="text-align: center">
			<h5 class="card-title">The Psychology of Money</h5>
			<p class="card-text">By Morgan Housel</p>
			<a href="details/mot/4">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; margin-top: 30px; height: 400px;">
		<img src="https://m.media-amazon.com/images/I/51+R3tGEsvL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-warning text-white" style="text-align: center">
			<h4 class="card-title">You Can</h4>
			<p class="card-text">By George Matthew Adams</p>
			<a href="details/mot/5">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 350px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/811wuvCKC2S._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-warning text-white" style="text-align: center">
			<h6 class="card-title">Power of Your Subconscious Mind</h6>
			<p class="card-text">By Dr. Joseph</p>
			<a href="details/mot/6">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 700px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/71Tlzg82tBL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-warning text-white" style="text-align: center">
			<h5 class="card-title">The Richest Man in Babylon</h5>
			<p class="card-text">By George S. Clason</p>
			<a href="details/mot/7">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 1050px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/91uKAmy5OML._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-warning text-white" style="text-align: center">
			<h6 class="card-title">365 Days of Positive Thinking</h6>
			<p class="card-text">By Jenny Kellett</p>
			<a href="details/mot/8">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-top: 30px;">
		<img src="https://m.media-amazon.com/images/I/71cfMcPaCdL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-warning text-white" style="text-align: center">
			<h6 class="card-title">365 Days of Positive Thinking</h6>
			<p class="card-text">By Dr. Satyajit Choudhary</p>
			<a href="details/mot/9">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 350px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/711fNGc9NoL._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-warning text-white" style="text-align: center">
			<h4 class="card-title">The Secret</h4>
			<p class="card-text">By Rhonda Byrne</p>
			<a href="details/mot/10">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 700px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/81HcKwVBK6L._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-warning text-white" style="text-align: center">
			<h5 class="card-title">Let The Universe Help You!</h5>
			<p class="card-text">By M. Alexander</p>
			<a href="details/mot/11">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>
	<div class="card" style="width: 300px; height: 400px; margin-left: 1050px; margin-top: -400px">
		<img src="https://m.media-amazon.com/images/I/91h480l8E-L._AC_UY327_FMwebp_QL65_.jpg"
		class="card-img-top crd-img" style="margin-left: 0px; margin-top: 0px;">
		<div class="card-body bg-warning text-white" style="text-align: center">
			<h4 class="card-title">Law of Attraction</h4>
			<p class="card-text">By Ryan James</p>
			<a href="details/mot/12">
				<button class="btn btn-outline-light btn-sm">Details</button>
			</a>
		</div>
	</div>		
<x-footer />