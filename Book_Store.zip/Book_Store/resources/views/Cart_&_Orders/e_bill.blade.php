<html>
    <head>
        <title>E Bill</title>

        <meta charset="utf-8">
  	    <meta name="viewport" content="width=device-width, initial-scale=1">
  	    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  	    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  	    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

        <style>
            body
		    {
			    background-image: url('https://i.pinimg.com/originals/73/77/cf/7377cf3bb5b747377c6b1f583da22299.jpg');
			    background-repeat: no-repeat;
			    background-attachment: fixed;
			    background-size: 100% 100%; 	
		    }
        </style>
    </head>

    <body class="container">
        <h3>User Information</h3>
        @foreach($user_info as $user)
            <p><b>User id:</b> {{$user->id}}</p>
            <p><b>User Name:</b> {{$user->First_Name}} {{$user->Last_Name}}</p>
            <p><b>User Email id:</b> {{$user->Email}}</p>
            <p>
                <b>Residential Address: </b>
                {{$user->Apartment}}, {{$user->Street}}, {{$user->City}}, {{$user->State}}.
            </p><br>
        @endforeach

        <h3>Order Information</h3>
        @foreach($order_info as $order)
            <p><b>Order Quantity:</b> {{$order->Quantity}}</p>
            <p><b>Order Total Amount Paid:</b> {{$order->Total_Cost}}</p>
            <p><b>Order Payment Method:</b> {{$order->Payment_Method}}</p>
            <p><b>Order Delivery Address: </b>{{$order->Delivery_Address}}</p><br>
        @endforeach

        <h3>Product Information</h3>
        @foreach($product_info as $product)
            <p><b>Product id:</b> {{$order->Product_id}}</p>
            <p><b>Product Theme:</b> {{$order->Theme}}</p>
            <p><b>Product Name:</b> {{$product->Name}}</p>
            <p><b>Product Author:</b> {{$product->Author}}</p>
            <p><b>Product Price per piece:</b> {{$product->Price}}</p>
            <p><b>Product's no. of pages:</b> {{$product->Print_Length}}</p>
        @endforeach
    </body>
</html>