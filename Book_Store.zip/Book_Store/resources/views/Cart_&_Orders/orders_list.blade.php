@include("layout.master")

<h1 style="margin-top: 30px;">Your Orders</h1>
<div style="margin-top: 30px;">
    <b style="margin-left: 100px; font-size: 18;">Book</b>
    <b style="margin-left: 160px; font-size: 18;">Details</b>
</div>
<hr>

@foreach($data as $theme)
    @foreach($theme as $detail)
        <img src="{{$detail->Image}}">
        <div style="margin-left: 300px; margin-top: -190px;">
            <p>
                <b>{{$detail->Name}}</b>
            </p>
            
            <p>
                Qty: <b>{{$detail->Quantity}}</b>
            </p>
            
            <p>
                Total Amount Paid: <b>₹{{$detail->Total_Cost}}</b>
            </p>
            
            <p>
                Delivery Status: <b>{{$detail->Delivery_Status}}</b>
            </p>
            <p style="margin-top: 20px;">
                <a href="/details/{{$detail->Theme}}/{{$detail->Product_id}}">
                    <button class="btn btn-outline-info">Product details</button>
                </a>
                <a href="/e_bill/{{$detail->Theme}}/{{$detail->Product_id}}/{{$detail->Quantity}}" 
                style="margin-left: 20px;">View e-bill</a>
            </p>
        </div>
        <hr style="margin-top: 30px;">
    @endforeach
@endforeach

<x-footer />