@include("layout.master")
    <form action="/order_product/{{$theme}}" method="POST">
        @csrf
        <h2 class="mt-4">Choose a way to pay ₹{{$data['Quantity'] * 0.88 * $data['product_price']}}</h2>
        @foreach($image as $item_1)
            <img src="{{$item_1->Image}}"
            style="width: 250px; height: 250px; margin-left: 0px;">
        @endforeach
        <div style="margin-left: 300px; margin-top: -250px; width: 290px;">
            <div>
                <p><b>{{$data['product_name']}}</b></p>
                <p>by <b>{{$data['product_author']}}</b></p>
                <p>
                    Quantity: <input type="number" readonly value="{{$data['Quantity']}}" 
                    style="background: rgba(0,0,0,0); border: none; font-weight: bold;" 
                    name="product_quantity" class="col-sm-3">
                </p>
                <p>
                    Total Price(GST inclusive)(₹): 
                    <b>
                        {{($data['Quantity']*$data['product_price']) + ($data['Quantity']*$data['product_price']*0.18)}}
                    </b>
                </p>
                <p>
                    Discount of 30%(₹): 
                    <b>-{{0.3 * $data['Quantity'] * $data['product_price']}}</b>
                </p>
                <p>
                    Total amount payable(₹): 
                    <input type="number" readonly value="{{$data['Quantity'] * 0.88 * $data['product_price']}}" 
                    style="background: rgba(0,0,0,0); border: none; font-weight: bold;" 
                    name="product_total_cost" class="col-sm-4">
                </p>
            </div>
        </div>
        
        <div class="form-group" style="margin-left: 620px; margin-top: -250px;">
            <h2>Payment options</h2>
            <div class="form-check">
                <label for="UPI" class="form-check-label mt-3">
                    <input type="radio" class="form-check-input" value="UPI" name="pay" checked>UPI
                </label>
            </div>
            <div class="form-check">
                <label for="Add a Credit, Debit or ATM card" class="form-check-label mt-3">
                    <input type="radio" class="form-check-input" value="Card"
                    name="pay">
                    Add a Credit, Debit or ATM card
                </label>
            </div>
            <div class="form-check">
                <label for="Net Banking" class="form-check-label mt-3">
                    <input type="radio" class="form-check-input" value="Net Banking" name="pay">
                    Net Banking
                </label>
            </div> 
            <div class="form-check">
                <label for="Cash On Delivery" class="form-check-label mt-3">
                    <input type="radio" class="form-check-input" value="Cash On Delivery" name="pay">
                    Cash on Delivery
                </label>
            </div>  
        </div>

        @foreach($address as $item_2)
            <div style="margin-top: 80px;">
                <p><b>Deliver to:</b></p> 
                    <input type="text" name="address" style="width: 650px; height: 100px;" 
                    value="{{$item_2->Apartment}}, {{$item_2->Street}}, {{$item_2->City}}, {{$item_2->State}}.">
            </div><br>
        @endforeach
        
        <div style="display: none;">
            <input type="number" value="{{$item_1->id}}" name="product_id">
        </div>

        <input type="submit" value="Place order" class="btn btn-outline-success">
    </form>
<x-footer />
