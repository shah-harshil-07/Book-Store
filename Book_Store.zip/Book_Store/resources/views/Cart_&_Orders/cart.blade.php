@include("layout.master")

<h1 style="margin-top: 30px;">Your Library</h1>
<div style="margin-top: 30px;">
    <b style="margin-left: 100px; font-size: 18;">Book</b>
    <b style="margin-left: 160px; font-size: 18;">Details</b>
    <b style="margin-left: 850px; font-size: 18;">Price(₹)</b>
</div>
<hr>

@foreach($data as $theme)
    @foreach($theme as $detail)
        <form action="/orders/{{$detail->Theme}}" method="GET">
            <img src="{{$detail->Image}}">
            <div style="margin-left: 300px; margin-top: -190px;">
                <p>
                    <input type="text" readonly value="{{$detail->Name}}" 
                    style="background: rgba(0,0,0,0); border: none; font-weight: bold;" 
                    name="product_name">
                    <div style="margin-left: 930px; margin-top: -40px;">
                        <input type="text" readonly value="{{$detail->Price}}"
                        style="background: rgba(0,0,0,0); border: none; font-weight: bold;
                        width: 40px;" name="product_price">
                    </div>
                </p>
                
                <p>
                by <input type="text" readonly value="{{$detail->Author}}"
                    style="background: rgba(0,0,0,0); border: none; font-weight: bold;" 
                    name="product_author">
                </p>

                <p class="form-group col-md-2" style="margin-left: -15px;">
                    <label for="Quantity"><b>Quantity</b></label>
                    <select name="Quantity" id="Quantity" class="form-control col-sm-5" 
                    style="margin-left: 80px; margin-top: -40px;">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                    </select>
                </p>

                <p style="margin-top: 20px;">
                    <a href="/details/{{$detail->Theme}}/{{$detail->Product_id}}">More Details</a>
                    <input type="submit" class="btn btn-outline-success ml-3" value="Order Now">
                </p>
            </div>
            
        </form>
        <a href="/delete_from_cart/{{$detail->Theme}}/{{$detail->Product_id}}" 
        style="margin-left: 300px;">
            <button class="btn btn-outline-danger">Delete from Library</button>
        </a>
        <hr style="margin-top: 30px;">
    @endforeach
@endforeach

<x-footer />