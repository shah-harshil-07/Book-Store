@include("layout.master")
        @foreach($data as $item)
            <div>
                <img src="{{$item->Image}}" style="width: 300px; 
                height: 300px; margin-top: 30px; margin-left: 0px;">
            </div>

            <div style="margin-left: 350px; margin-top: -300px;">
                <h1>{{$item->Name}}</h1> 
                <p>By <b>{{$item->Author}}</b></p><br>
                <p>Original Price: <b>₹{{$item->Price}}</b></p>
                <p>18% CGST: <b>₹{{0.18*$item->Price}}</b></p>
                <p>Total Price: <b>₹{{$item->Price + 0.18*$item->Price}}</b></p>
                <p>
                    <a href="/cart/{{$theme}}/{{$item->id}}">
                        <button class="btn btn-outline-primary">
                            Add to Library
                        </button>   
                    </a>
                    <div>
                        <form action="/orders/{{$theme}}" method="GET">
                            <input type="text" readonly value="{{$item->Name}}" 
                            style="display: none;" name="product_name" class="col-sm-3">
                            <input type="text" readonly value="{{$item->Price}}" 
                            style="display: none;" name="product_price" class="col-sm-3">
                            <input type="text" readonly value="{{$item->Author}}" 
                            style="display: none;" name="product_author" class="col-sm-3">
                            <div class="form-group col-md-2" style="margin-left: -15px;">
                                <label for="Quantity"><b>Quantity</b></label>
                                <select name="Quantity" id="Quantity" class="form-control col-sm-5" 
                                style="margin-left: 80px; margin-top: -40px;">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    <option value="10">10</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-outline-success" 
                            style="margin-left: 150px; margin-top: -53px;">
                                Order Now
                            </button>
                        </form>
                    </div>
                </p>
            </div>

            <div style="margin-top: 30px;">
                <h2>Book Description</h2>
                {{$item->Description}}
            </div>
            
            <div style="margin-top: 50px;">
                <h2>Other details of book</h2>
                <p><b>Publisher:</b> {{$item->Publisher}}</p>
                <p><b>Publication Date:</b> {{$item->Publish_date}}</p>
                <p><b>No. of pages:</b> {{$item->Print_Length}}</p>
            </div>
        @endforeach
<x-footer />