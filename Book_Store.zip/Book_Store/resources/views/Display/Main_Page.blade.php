@include("layout.master")

@if(session("cart"))
	<?php echo "<script>alert('Item already added in cart')</script>"; ?>
@endif

@if(session("order"))
	<?php echo "<script>alert('Order placed successfully')</script>"; ?>
@endif

@if(session("delete_from_cart"))
	<?php echo "<script>alert('Item deleted from library')</script>"; ?>
@endif
	<div id="demo" class="carousel slide" data-ride="carousel">
	 	<ul class="carousel-indicators">
	    	<li data-target="#demo" data-slide-to="0" class="active"></li>
	    	<li data-target="#demo" data-slide-to="1"></li>
	    	<li data-target="#demo" data-slide-to="2"></li>
	  	</ul>
	  	<div class="carousel-inner">
	    	<div class="carousel-item active">
				<a href="details/mag/1">
					<img src="https://image.shutterstock.com/image-vector/promo-sale-banner-library-bookshop-260nw-1790872166.jpg" class="mag">
				</a>
	    </div>
    	<div class="carousel-item">
			<a href="details/mag/2">
				<img src="https://sm.mashable.com/t/mashable_sea/photo/default/big-bad-wolf-1548115188_xzf9.960.jpg" class="mag">
			</a>  
    	</div>
    	<div class="carousel-item">
			<a href="details/mag/3">
				<img src="https://previews.123rf.com/images/pattarasin/pattarasin1608/pattarasin160800029/61300199-sale-banner-template-80-off-vector-concept-of-online-shop.jpg" class="mag">
			</a>   
    	</div>
  		<a class="carousel-control-prev" href="#demo" data-slide="prev">
  			<span class="carousel-control-prev-icon"></span>
  		</a>
  		<a class="carousel-control-next" href="#demo" data-slide="next">
    		<span class="carousel-control-next-icon"></span>
  		</a>
	</div>

	<p id="demo"></p>
	<h2 style="margin-top: 30px;">
		FROM YOUR LIBRARY 
		<a href="/cart">
			<span style="font-size: 15;">Go to Library</span>
		</a>
	</h2>
	<div style="display: none;">{{$n=1}}</div>
	<div>
		@if(Session::has("id"))
			<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
				@foreach($a as $table)
					@foreach($table as $name)
						@if($n < 6)
							<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
							margin-top: 0px; height: 272px;">
								
								<a href="details/{{$name->Theme}}/{{$name->Product_id}}">
									<img src="{{$name->Image}}" style="margin-left: 0px; 
									width: 200px;">
								</a>

								<div>
									<b><center>{{$name->Name}}</center></b>
								</div>
							</div>
						@endif
						<div style="display: none;">{{$n++}}</div>
					@endforeach
				@endforeach
			</div><br><br>
		@else
			<div>
				<a href="/login">Login</a> to access your library. 
				OR, <a href="register">Register</a> if you are a new user.
			</div><br><br>
		@endif
	</div>

	<h2>NEW ARRIVALS</h2>
	
	<div>
		<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
			@foreach($new_arr as $item)
				<div class="d-inline-block" style="width: 200px; 
					margin-left: 60px; margin-top: 0px; height: 272px;">
					
					<a href="details/new_arr/{{$item->id}}">
						<img src="{{$item->Image}}" style="margin-left: 0px; width: 200px;">
					</a>

					<div>
						<b><center>{{$item->Name}}</center></b>
					</div>
				</div>
			@endforeach
		</div>
	</div><br><br>

	<h2>READ WONDERFUL MAGAZINES</h2>
	<div>
		<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
			@foreach($mag as $item)
				<div class="d-inline-block" style="width: 200px; 
					margin-left: 60px; margin-top: 0px; height: 272px;">
					
					<a href="details/mag/{{$item->id}}">
						<img src="{{$item->Image}}" style="margin-left: 0px; width: 200px;">
					</a>

					<div>
						<b><center>{{$item->Name}}</center></b>
					</div>
				</div>
			@endforeach
		</div><br><br>
	</div>

	<h2>PICK A THEME</h2>
	<a href="mystery">
		<button class="btn btn-outline-dark theme">Mystery, Thriller & Crime</button>
	</a>
	<a href="romance">
		<button class="btn btn-outline-danger theme">Romance, Couple & Love</button>
	</a>
	<a href="sci">
		<button class="btn btn-outline-info theme">Science Fiction</button>
	</a>
	<a href="biz">
		<button class="btn btn-outline-success theme">Business, Management & Finance</button>
	</a>
	<a href="mot">
		<button class="btn btn-outline-warning theme">Motivation</button>
	</a>
	<a href="bio">
		<button class="btn btn-outline-secondary theme">Biography</button>
	</a><br><br><br><br>

<x-footer />