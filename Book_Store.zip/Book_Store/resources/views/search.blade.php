@include("layout.master")

<div style="display: none;">{{$a=1}}</div>

<div style="margin-top: 30px;">
	<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
		@foreach($mystery as $theme_1)
			@foreach($theme_1 as $item_1)
				@if($a < 6)
					<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
					margin-top: 0px; height: 272px;">
						
						<a href="details/mystery/{{$item_1->id}}">
							<img src="{{$item_1->Image}}" style="margin-left: 0px; 
							width: 200px;">
						</a>

						<div>
							<b><center>{{$item_1->Name}}</center></b>
						</div>
					</div>
				@endif
				<div style="display: none;">{{$a++}}</div>
			@endforeach
		@endforeach
	</div><br><br>
</div>

<div style="display: none;">{{$b=1}}</div>

<div style="margin-top: 30px;">
	<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
		@foreach($romance as $theme_2)
			@foreach($theme_2 as $item_2)
				@if($b < 6)
					<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
					margin-top: 0px; height: 272px;">
						
						<a href="details/romance/{{$item_2->id}}">
							<img src="{{$item_2->Image}}" style="margin-left: 0px; 
							width: 200px;">
						</a>

						<div>
							<b><center>{{$item_2->Name}}</center></b>
						</div>
					</div>
				@endif
				<div style="display: none;">{{$b++}}</div>
			@endforeach
		@endforeach
	</div><br><br>
</div>

<div style="display: none;">{{$c=1}}</div>

<div style="margin-top: 30px;">
	<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
		@foreach($sci_fi as $theme_3)
			@foreach($theme_3 as $item_3)
				@if($c < 6)
					<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
					margin-top: 0px; height: 272px;">
						
						<a href="details/sci_fi/{{$item_3->id}}">
							<img src="{{$item_3->Image}}" style="margin-left: 0px; 
							width: 200px;">
						</a>

						<div>
							<b><center>{{$item_3->Name}}</center></b>
						</div>
					</div>
				@endif
				<div style="display: none;">{{$c++}}</div>
			@endforeach
		@endforeach
	</div><br><br>
</div>

<div style="display: none;">{{$d=1}}</div>

<div style="margin-top: 30px;">
	<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
		@foreach($biz as $theme_4)
			@foreach($theme_4 as $item_4)
				@if($d < 6)
					<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
					margin-top: 0px; height: 272px;">
						
						<a href="details/biz/{{$item_4->id}}">
							<img src="{{$item_4->Image}}" style="margin-left: 0px; 
							width: 200px;">
						</a>

						<div>
							<b><center>{{$item_4->Name}}</center></b>
						</div>
					</div>
				@endif
				<div style="display: none;">{{$d++}}</div>
			@endforeach
		@endforeach
	</div><br><br>
</div>

<div style="display: none;">{{$e=1}}</div>

<div style="margin-top: 30px;">
	<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
		@foreach($mot as $theme_5)
			@foreach($theme_5 as $item_5)
				@if($e < 6)
					<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
					margin-top: 0px; height: 272px;">
						
						<a href="details/mot/{{$item_5->id}}">
							<img src="{{$item_5->Image}}" style="margin-left: 0px; 
							width: 200px;">
						</a>

						<div>
							<b><center>{{$item_5->Name}}</center></b>
						</div>
					</div>
				@endif
				<div style="display: none;">{{$e++}}</div>
			@endforeach
		@endforeach
	</div><br><br>
</div>

<div style="display: none;">{{$f=1}}</div>

<div style="margin-top: 30px;">
	<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
		@foreach($bio as $theme_6)
			@foreach($theme_6 as $item_6)
				@if($f < 6)
					<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
					margin-top: 0px; height: 272px;">
						
						<a href="details/bio/{{$item_6->id}}">
							<img src="{{$item_6->Image}}" style="margin-left: 0px; 
							width: 200px;">
						</a>

						<div>
							<b><center>{{$item_6->Name}}</center></b>
						</div>
					</div>
				@endif
				<div style="display: none;">{{$f++}}</div>
			@endforeach
		@endforeach
	</div><br><br>
</div>

<div style="display: none;">{{$g=1}}</div>

<div style="margin-top: 30px;">
	<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
		@foreach($mag as $theme_7)
			@foreach($theme_7 as $item_7)
				@if($g < 6)
					<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
					margin-top: 0px; height: 272px;">
						
						<a href="details/mag/{{$item_7->id}}">
							<img src="{{$item_7->Image}}" style="margin-left: 0px; 
							width: 200px;">
						</a>

						<div>
							<b><center>{{$item_7->Name}}</center></b>
						</div>
					</div>
				@endif
				<div style="display: none;">{{$g++}}</div>
			@endforeach
		@endforeach
	</div><br><br>
</div>

<div style="display: none;">{{$h=1}}</div>

<div style="margin-top: 30px;">
	<div style="display: flex; flex-wrap: wrap; align-content:stretch;">
		@foreach($new_arr as $theme_8)
			@foreach($theme_8 as $item_8)
				@if($h < 6)
					<div class="d-inline-block" style="width: 200px; margin-left: 60px; 
					margin-top: 0px; height: 272px;">
						
						<a href="details/new_arr/{{$item_8->id}}">
							<img src="{{$item_8->Image}}" style="margin-left: 0px; 
							width: 200px;">
						</a>

						<div>
							<b><center>{{$item_8->Name}}</center></b>
						</div>
					</div>
				@endif
				<div style="display: none;">{{$h++}}</div>
			@endforeach
		@endforeach
	</div><br><br>
</div>