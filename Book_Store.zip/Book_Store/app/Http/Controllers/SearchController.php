<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SearchController extends Controller
{
    function search(Request $req)
    {
        $search = $req->book_name;
        $mystery = array();
        $romance = array();
        $sci_fi = array();
        $biz = array();
        $mot = array();
        $bio = array();
        $mag = array();
        $new_arr = array();
        array_push($mystery, DB::table("mystery")
                               ->select("Name","Image","id")
                               ->where("Name","LIKE","%".$search."%")
                               ->get()
        );
        array_push($romance, DB::table("romance")
                               ->select("Name","Image","id")
                               ->where("Name","LIKE","%".$search."%")
                               ->get()
        );
        array_push($sci_fi, DB::table("sci_fi")
                               ->select("Name","Image","id")
                               ->where("Name","LIKE","%".$search."%")
                               ->get()
        );
        array_push($biz, DB::table("biz")
                               ->select("Name","Image","id")
                               ->where("Name","LIKE","%".$search."%")
                               ->get()
        );
        array_push($mot, DB::table("mot")
                               ->select("Name","Image","id")
                               ->where("Name","LIKE","%".$search."%")
                               ->get()
        );
        array_push($bio, DB::table("bio")
                               ->select("Name","Image","id")
                               ->where("Name","LIKE","%".$search."%")
                               ->get()
        );
        array_push($mag, DB::table("mag")
                               ->select("Name","Image","id")
                               ->where("Name","LIKE","%".$search."%")
                               ->get()
        );
        array_push($new_arr, DB::table("new_arr")
                               ->select("Name","Image","id")
                               ->where("Name","LIKE","%".$search."%")
                               ->get()
        );
        return view("search",["mystery"=>$mystery,
                              "romance"=>$romance,
                              "sci_fi"=>$sci_fi,
                              "biz"=>$biz,
                              "mot"=>$mot,
                              "bio"=>$bio,
                              "mag"=>$mag,
                              "new_arr"=>$new_arr
                            ]
        );
    }
}
?>