<?php

    namespace App\Http\Controllers;

    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use App\Models\User;

    class UsersController extends Controller
    {
        function register(Request $req)
        {
            $fname = $req->fname;
            $lname = $req->lname;
            $email = $req->email;
            $password = md5($req->password);
            $apt = $req->apt;
            $street = $req->street;
            $city = $req->city;
            $state = $req->state;

            DB::table("users")
            ->insert([
                "First_Name"=>$fname,
                "Last_Name"=>$lname,
                "Email"=>$email,
                "Password"=>$password,
                "Apartment"=>$apt,
                "Street"=>$street,
                "City"=>$city,
                "State"=>$state
            ]);

            $req->session("user")->put($fname);

            return redirect("main");
        }

        function login(Request $req)
        {
            $data = User::where("Email","=",$req->email)->first();
        
            if($data != NULL)
            {
                $pass_1 = md5($req->password);
                $pass_2 = $data->Password;
                
                if($pass_1 == $pass_2)
                { 
                    session(["user"=>$data->First_Name,"id"=>$data->id]);
                    return redirect("main");
                }
                else
                {
                    $req->session()->flash("password","incorrect");
                    return redirect("login");
                }
            }
            else
            {
                $req->session()->flash("email","incorrect");
                return redirect("login");
            }
        }

        function logout(Request $req)
        {
            $req->session()->pull("id");
            $req->session()->pull("user");
            return redirect("login");
        }

        function acc_details()
        {
            $id = session("id");
            $data = DB::table("users")->select("*")->where("id",$id)->get();
            return view("Accounts.acc_set",["data"=>$data]);
        }

        function acc_update(Request $req)
        {
            $data = DB::table("users")
                        ->select("*")
                        ->where("First_Name",session("user"))
                        ->update([
                            "First_Name"=>$req->fname,
                            "Last_Name"=>$req->lname,
                            "Email"=>$req->email,
                            "Apartment"=>$req->apt,
                            "Street"=>$req->street,
                            "City"=>$req->city,
                            "State"=>$req->state
            ]);

            return redirect("login");
        }

        function alt_pass(Request $req)
        {
            if($req->pass_1 != $req->pass_2)
            {
                $req->session()->flash("pass","error");
                return view("Accounts.alt_pass");
            }
            $password = $req->input("pass_1");
            $pass = md5($password);
            $data = DB::table('users')
                        ->select("Password")
                        ->where("First_Name",session("user"))
                        ->update(["Password"=>$pass
            ]);
            
            return redirect("main");
        }
    }
?>