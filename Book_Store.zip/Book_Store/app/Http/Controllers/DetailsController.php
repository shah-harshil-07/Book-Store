<?php

    namespace App\Http\Controllers;

    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\DB;
    use App\Models\cart;

    class DetailsController extends Controller
    {
        function index($table,$id)
        {
            $data = DB::table($table)
                        ->where("id",$id)
                        ->get();
            return view("Display.Details_Page",["data"=>$data,"theme"=>$table]);
        }

        function display()
        {
            if(session("id"))
            {
                $id = session("id");
                $a = array();

                array_push($a, DB::select("SELECT cart.Theme, cart.Product_id, mystery.Image, 
                                mystery.Name, mystery.Author, mystery.Price FROM cart 
                                INNER JOIN mystery ON cart.Product_id = mystery.id WHERE 
                                cart.User_id = $id AND cart.Theme = 'mystery'")
                );
                array_push($a, DB::select("SELECT cart.Theme, cart.Product_id, romance.Image, 
                                romance.Name, romance.Author, romance.Price FROM cart 
                                INNER JOIN romance ON cart.Product_id = romance.id WHERE 
                                cart.User_id = $id AND cart.Theme = 'romance'")
                );
                array_push($a, DB::select("SELECT cart.Theme, cart.Product_id, sci_fi.Image, 
                                sci_fi.Name, sci_fi.Author, sci_fi.Price FROM cart 
                                INNER JOIN sci_fi ON cart.Product_id = sci_fi.id WHERE 
                                cart.User_id = $id AND cart.Theme = 'sci_fi'")
                );
                array_push($a, DB::select("SELECT cart.Theme, cart.Product_id, biz.Image, 
                                biz.Name, biz.Author, biz.Price FROM cart INNER JOIN biz ON 
                                cart.Product_id = biz.id WHERE cart.User_id = $id AND 
                                cart.Theme = 'biz'")
                );
                array_push($a, DB::select("SELECT cart.Theme, cart.Product_id, mot.Image, 
                                mot.Name, mot.Author, mot.Price FROM cart INNER JOIN mot ON 
                                cart.Product_id = mot.id WHERE cart.User_id = $id AND 
                                cart.Theme = 'mot'")
                );
                array_push($a, DB::select("SELECT cart.Theme, cart.Product_id, bio.Image, 
                                bio.Name, bio.Author, bio.Price FROM cart INNER JOIN bio ON 
                                cart.Product_id = bio.id WHERE cart.User_id = $id AND 
                                cart.Theme = 'bio'")
                );
                array_push($a, DB::select("SELECT cart.Theme, cart.Product_id, mag.Image, 
                                mag.Name, mag.Author, mag.Price FROM cart INNER JOIN mag ON 
                                cart.Product_id = mag.id WHERE cart.User_id = $id AND 
                                cart.Theme = 'mag'")
                );
                array_push($a, DB::select("SELECT cart.Theme, cart.Product_id, new_arr.Image, 
                                new_arr.Name, new_arr.Author, new_arr.Price FROM cart 
                                INNER JOIN new_arr ON cart.Product_id = new_arr.id WHERE 
                                cart.User_id = $id AND cart.Theme = 'new_arr'")
                );
                    
                $new_arr = DB::table("new_arr")->get();
                $mag = DB::table("mag")->get();
                return view("Display.Main_Page",["new_arr"=>$new_arr,"a"=>$a,"mag"=>$mag]);
            }
            else
            {
                $new_arr = DB::table("new_arr")->get();
                $mag = DB::table("mag")->get();
                return view("Display.Main_Page",["new_arr"=>$new_arr,"mag"=>$mag]);
            }
        }

        function add_to_cart(Request $req,$theme, $id)
        {
            $user_id = DB::table("users")
                            ->select("id")
                            ->where("id",session("id"))
                            ->get();

            foreach($user_id as $item)
            {
                $data = cart::where("User_id",$item->id)
                               ->where("Theme",$theme)    
                               ->where("Product_id",$id)     
                               ->first();
                if($data != NULL)
                {
                    $req->session()->flash("cart","yes");
                    return redirect("/main");
                }
                else
                {
                    DB::table("cart")
                    ->select("*")
                    ->insert([
                        "User_id"=>$item->id,
                        "Theme"=>$theme,
                        "Product_id"=>$id
                    ]);
                    return redirect("/cart");
                }
            }
        }

        function display_cart()
        {
            $id = session("id");
            $a = array();
            
            array_push($a,  DB::select("SELECT cart.Theme, cart.Product_id, mystery.Image, 
                                mystery.Name, mystery.Author, mystery.Price FROM cart 
                                INNER JOIN mystery ON cart.Product_id = mystery.id WHERE 
                                cart.User_id = $id AND cart.Theme = 'mystery'")
            );
            array_push($a,  DB::select("SELECT cart.Theme, cart.Product_id, romance.Image, 
                                romance.Name, romance.Author, romance.Price FROM cart 
                                INNER JOIN romance ON cart.Product_id = romance.id WHERE 
                                cart.User_id = $id AND cart.Theme = 'romance'")
            );
            array_push($a,  DB::select("SELECT cart.Theme, cart.Product_id, sci_fi.Image, 
                                sci_fi.Name, sci_fi.Author, sci_fi.Price FROM cart 
                                INNER JOIN sci_fi ON cart.Product_id = sci_fi.id WHERE 
                                cart.User_id = $id AND cart.Theme = 'sci_fi'")
            );
            array_push($a,  DB::select("SELECT cart.Theme, cart.Product_id, biz.Image, 
                                biz.Name, biz.Author, biz.Price FROM cart INNER JOIN biz ON 
                                cart.Product_id = biz.id WHERE cart.User_id = $id AND 
                                cart.Theme = 'biz'")
            );
            array_push($a, DB::select("SELECT cart.Theme, cart.Product_id, mot.Image, 
                                mot.Name, mot.Author, mot.Price FROM cart INNER JOIN mot ON 
                                cart.Product_id = mot.id WHERE cart.User_id = $id AND 
                                cart.Theme = 'mot'")
            );
            array_push($a, DB::select("SELECT cart.Theme, cart.Product_id, bio.Image, 
                                bio.Name, bio.Author, bio.Price FROM cart INNER JOIN bio ON 
                                cart.Product_id = bio.id WHERE cart.User_id = $id AND 
                                cart.Theme = 'bio'")
            );
            array_push($a, DB::select("SELECT cart.Theme, cart.Product_id, mag.Image, 
                                mag.Name, mag.Author, mag.Price FROM cart INNER JOIN mag ON 
                                cart.Product_id = mag.id WHERE cart.User_id = $id AND 
                                cart.Theme = 'mag'")
            );
            array_push($a, DB::select("SELECT cart.Theme, cart.Product_id, new_arr.Image, 
                                new_arr.Name, new_arr.Author, new_arr.Price FROM cart 
                                INNER JOIN new_arr ON cart.Product_id = new_arr.id WHERE 
                                cart.User_id = $id AND cart.Theme = 'new_arr'")
            );
                
            return view("Cart_&_Orders.cart",["data"=>$a]);
        }

        function delete_from_cart($theme,$id,Request $req)
        {
            $data = DB::table("cart")
                        ->select("*")
                        ->where("User_id",session("id"))
                        ->where("Theme",$theme)
                        ->where("Product_id",$id)
                        ->delete();
            $req->session()->flash("delete_from_cart","yes");
            return redirect("/main");
        }

        function order_display(Request $req,$theme)
        {
            $image = DB::table($theme)
                        ->select("Image","id")
                        ->where("Name",$req->input("product_name"))
                        ->get();
            $data = $req->input();
            $address = DB::table("users")
                        ->select("Apartment","Street","City","State")
                        ->where("id",session("id"))
                        ->get();
            return view("Cart_&_Orders.orders",["image"=>$image,"data"=>$data,
                    "address"=>$address,"theme"=>$theme]);
        }

        function order_product($theme,Request $req)
        {
            DB::table("orders")
                ->select("*")
                ->insert([
                    "User_id"=>session("id"),
                    "Theme"=>$theme,
                    "Product_id"=>$req->product_id,
                    "Quantity"=>$req->product_quantity,
                    "Total_Cost"=>$req->product_total_cost,
                    "Payment_Method"=>$req->pay,
                    "Delivery_Address"=>$req->address,
                    "Delivery_Status"=>"Pending"
                ]);
            $req->session()->flash("order","successful");
            return redirect("/main");
        }

        function orders_list()
        {
            $id = session("id");
            $a = array();
            
            array_push($a,  DB::select("SELECT orders.Theme, orders.Product_id, orders.Quantity, 
                                orders.Total_Cost, orders.Delivery_Status, mystery.Image, 
                                mystery.Name, mystery.Author, mystery.Price FROM orders 
                                INNER JOIN mystery ON orders.Product_id = mystery.id WHERE 
                                orders.User_id = $id AND orders.Theme = 'mystery'")
            );
            array_push($a,  DB::select("SELECT orders.Theme, orders.Product_id, orders.Quantity, 
                                orders.Total_Cost, orders.Delivery_Status, romance.Image, 
                                romance.Name, romance.Author, romance.Price FROM orders 
                                INNER JOIN romance ON orders.Product_id = romance.id WHERE 
                                orders.User_id = $id AND orders.Theme = 'romance'")
            );
            array_push($a,  DB::select("SELECT orders.Theme, orders.Product_id, orders.Quantity, 
                                orders.Total_Cost, orders.Delivery_Status, sci_fi.Image, 
                                sci_fi.Name, sci_fi.Author, sci_fi.Price FROM orders INNER JOIN 
                                sci_fi ON orders.Product_id = sci_fi.id WHERE orders.User_id = 
                                $id AND orders.Theme = 'sci_fi'")
            );
            array_push($a,  DB::select("SELECT orders.Theme, orders.Product_id, orders.Quantity, 
                                orders.Total_Cost, orders.Delivery_Status, biz.Image, biz.Name, 
                                biz.Author, biz.Price FROM orders INNER JOIN biz ON 
                                orders.Product_id = biz.id WHERE orders.User_id = $id AND 
                                orders.Theme = 'biz'")
            );
            array_push($a, DB::select("SELECT orders.Theme, orders.Product_id, orders.Quantity, 
                                orders.Total_Cost, orders.Delivery_Status, mot.Image, mot.Name, 
                                mot.Author, mot.Price FROM orders INNER JOIN mot ON 
                                orders.Product_id = mot.id WHERE orders.User_id = $id AND 
                                orders.Theme = 'mot'")
            );
            array_push($a, DB::select("SELECT orders.Theme, orders.Product_id, orders.Quantity, 
                                orders.Total_Cost, orders.Delivery_Status, bio.Image, bio.Name, 
                                bio.Author, bio.Price FROM orders INNER JOIN bio ON 
                                orders.Product_id = bio.id WHERE orders.User_id = $id AND 
                                orders.Theme = 'bio'")
            );
            array_push($a, DB::select("SELECT orders.Theme, orders.Product_id, orders.Quantity, 
                                orders.Total_Cost, orders.Delivery_Status, mag.Image, mag.Name, 
                                mag.Author, mag.Price FROM orders INNER JOIN mag ON 
                                orders.Product_id = mag.id WHERE orders.User_id = $id AND 
                                orders.Theme = 'mag'")
            );
            array_push($a, DB::select("SELECT orders.Theme, orders.Product_id, orders.Quantity, 
                                orders.Total_Cost, orders.Delivery_Status, new_arr.Image, 
                                new_arr.Name, new_arr.Author, new_arr.Price FROM orders 
                                INNER JOIN new_arr ON orders.Product_id = new_arr.id WHERE 
                                orders.User_id = $id AND orders.Theme = 'new_arr'")
            );
                
            return view("Cart_&_Orders.orders_list",["data"=>$a]);
        }

        function e_bill($theme,$prod_id,$qty)
        {
            $user_info = DB::table("users")
                            ->select("id","First_Name","Last_Name","Email","Apartment","Street",
                                     "City","State")
                            ->where("id",session("id"))
                            ->get();

            $order_info = DB::table("orders")
                            ->select("Quantity","Total_Cost","Payment_Method","Delivery_Address",
                                     "Product_id","Theme")
                            ->where("User_id",session("id"))
                            ->where("Theme",$theme)
                            ->where("Product_id",$prod_id)
                            ->where("Quantity",$qty)
                            ->get();

            $product_info = DB::table($theme)
                                ->select("Name","Author","Price","Print_Length")
                                ->where("id",$prod_id)
                                ->get();

            return view("Cart_&_Orders.e_bill",["user_info"=>$user_info,
                                                "order_info"=>$order_info,
                                                "product_info"=>$product_info
                        ]);
        }
    }
?>