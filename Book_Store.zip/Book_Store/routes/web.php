<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DetailsController;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\SearchController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get("/main",[DetailsController::class,"display"]);
Route::view("/login","Login_&_Register.Login")->middleware("no_login");
Route::view("/register","Login_&_Register.Register");
Route::post("/register",[UsersController::class,"register"]);
Route::post("/login",[UsersController::class,"login"]);
Route::get("/logout",[UsersController::class,"logout"]);
Route::get("/search",[SearchController::class,"search"]);

Route::group(["middleware"=>["check_user"]],function(){

    Route::view("/mystery","Theme.Product_mystery");
    Route::view("/romance","Theme.Product_romance");
    Route::view("/sci","Theme.Product_sci");
    Route::view("/biz","Theme.Product_biz");
    Route::view("/mot","Theme.Product_mot");
    Route::view("/bio","Theme.Product_bio");
    Route::get("/details/{table}/{id}",[DetailsController::class,"index"]);
    Route::get("/acc_set",[UsersController::class,"acc_details"]);
    Route::put("/acc_update",[UsersController::class,"acc_update"]);
    Route::view("/alt_pass","Accounts.alt_pass"); 
    Route::put("/alt_pass",[UsersController::class,"alt_pass"]);  
    Route::get("/cart/{theme}/{id}",[DetailsController::class,"add_to_cart"]); 
    Route::get("/cart",[DetailsController::class,"display_cart"]);
    Route::get("/delete_from_cart/{theme}/{id}",[DetailsController::class,"delete_from_cart"]);
    Route::get("/orders/{theme}",[DetailsController::class,"order_display"]);
    Route::post("/order_product/{theme}",[DetailsController::class,"order_product"]);
    Route::get("/orders_list",[DetailsController::class,"orders_list"]);
    Route::get("/e_bill/{theme}/{product_id}/{quantity}",[DetailsController::class,"e_bill"]);
});
